create type public.app_role as enum ('admin', 'user');
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create or replace function public.assign_first_admin()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created_admin after insert on auth.users for each row execute function public.assign_first_admin();

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'outras',
  brand text not null default '',
  price numeric(10,2) not null default 0,
  puffs integer not null default 0,
  description text not null default '',
  flavors text[] not null default '{}',
  image_url text,
  is_launch boolean not null default false,
  sold_out boolean not null default false,
  rechargeable boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "Anyone can view products" on public.products for select to anon, authenticated using (true);
create policy "Admins insert products" on public.products for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins update products" on public.products for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins delete products" on public.products for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

create policy "Public read pod images" on storage.objects for select using (bucket_id = 'pod-images');
create policy "Admins upload pod images" on storage.objects for insert to authenticated with check (bucket_id = 'pod-images' and public.has_role(auth.uid(), 'admin'));
create policy "Admins update pod images" on storage.objects for update to authenticated using (bucket_id = 'pod-images' and public.has_role(auth.uid(), 'admin'));
create policy "Admins delete pod images" on storage.objects for delete to authenticated using (bucket_id = 'pod-images' and public.has_role(auth.uid(), 'admin'));

insert into public.products (name, category, brand, price, puffs, description, flavors, image_url, is_launch, sold_out, rechargeable, sort_order) values
('Fume 5.000','outras','Fume',50.0,5000,'',ARRAY['Limão gelado','Pêssego e Banana','Abacaxi, Morango e coco','Maracujá e pêssego']::text[],'/pods/fume-5-000.jpg',false,false,false,0),
('Lost Mary MO 5.000','lostmary','Lost Mary',55.0,5000,'',ARRAY['Menta','Ameixa e menta']::text[],'/pods/lost-mary-mo-5-000.jpg',false,false,false,1),
('EBDesign TE 6.000','outras','EBDesign',55.0,6000,'',ARRAY['Menta','Morango, abacaxi e maracujá','Bala de limão','Maçã e pêssego','Abacaxi morango e laranja','Uva','Morango']::text[],'/pods/ebdesign-te-6-000.jpg',false,false,false,2),
('Lost Mary MO 10.000','lostmary','Lost Mary',60.0,10000,'',ARRAY['Manga','Lichia e melão','Melancia']::text[],'/pods/lost-mary-mo-10-000.jpg',false,false,false,3),
('Nik Bar 10.000','outras','Nik Bar',65.0,10000,'',ARRAY['Cereja e Melancia','Maracujá e kiwi','Morango e kiwi','Uva','Melancia gelada']::text[],'/pods/nik-bar-10-000.jpg',false,false,false,4),
('Lost Mary 15.000','lostmary','Lost Mary',68.0,15000,'',ARRAY['Maçã verde','Menta','Uva']::text[],'/pods/lost-mary-15-000.jpg',true,false,false,5),
('Waka 25.000','waka','Waka',73.0,25000,'',ARRAY['Morango e pêssego','Melancia e pêssego','Menta']::text[],'/pods/waka-25-000.jpg',false,false,false,6),
('Life Pod 8k c/ Bateria','outras','Life Pod',80.0,8000,'Com bateria · cartucho avulso R$ 50 · boa durabilidade',ARRAY['Maçã verde','Kiwi','Maçã e melão','Lichia']::text[],'/pods/life-pod-8k-c-bateria.jpg',false,false,true,7),
('Wefume 30.000','outras','Fume',80.0,30000,'Tela touch · não damos garantia','{}'::text[],'/pods/wefume-30-000.jpg',true,true,false,8),
('Fume 15.000','outras','Fume',80.0,15000,'',ARRAY['Menta','Manga, Banana e Abacaxi','Morango e Banana']::text[],'/pods/fume-15-000.jpg',false,false,false,9),
('Lost Mary 20.000','lostmary','Lost Mary',80.0,20000,'','{}'::text[],'/pods/lost-mary-20-000.jpg',false,true,false,10),
('Waka 33.000','waka','Waka',80.0,33000,'',ARRAY['Menta','Melancia','Cereja','Maçã verde']::text[],'/pods/waka-33-000.jpg',true,false,false,11),
('Lost Mary M 30.000','lostmary','Lost Mary',85.0,30000,'Pod de 2 Sabores',ARRAY['Laranja / chá verde']::text[],'/pods/lost-mary-m-30-000.jpg',false,false,false,12),
('Geek Bar 35.000','outras','Geek Bar',85.0,35000,'',ARRAY['Maçã','Pêssego e framboesa','Blueberry e framboesa','Morango','Maracujá e kiwi','Morango e kiwi','Morango frozen','Menta','Abacaxi e coco gelado','Amora e bluberry']::text[],'/pods/geek-bar-35-000.jpg',true,false,false,13),
('HQD Graze Plus 30k','outras','HQD',85.0,30000,'','{}'::text[],'/pods/hqd-graze-plus-30k.jpg',true,true,false,14),
('Dinner Luma 20.000','outras','Dinner',85.0,20000,'',ARRAY['Maçã e pêssego gelado','Menta gelada','Melancia','Morango','Uva','Manga']::text[],'/pods/dinner-luma-20-000.jpg',true,false,false,15),
('Nik Bar 30k','outras','Nik Bar',90.0,30000,'',ARRAY['Morango e kiwi','Melancia','Uva']::text[],'/pods/nik-bar-30k.jpg',false,false,false,16),
('Waka 50.000','waka','Waka',90.0,50000,'','{}'::text[],'/pods/waka-50-000.jpg',true,true,false,17),
('Dojo 40k','outras','Dojo',95.0,40000,'',ARRAY['Maracujá, Manga e Laranja','Amora','Blueberry','Maçã','Uva','Frutas cítricas']::text[],'/pods/dojo-40k.jpg',false,false,false,18),
('Rabbeats 50.000','outras','Rabbeats',100.0,50000,'',ARRAY['Melancia','Melancia e pêssego','Fanta morango','Menta gelada','Amora','Maçã Verde']::text[],'/pods/rabbeats-50-000.jpg',false,false,false,19),
('Lost Mary 35.000 Dura','lostmary','Lost Mary',100.0,35000,'',ARRAY['Mango gelada','Menthol','Laranja maracujá goiaba','Tropical','Maçã Verde']::text[],'/pods/lost-mary-35-000-dura.jpg',false,false,false,20),
('Nik Bar 40.000','outras','Nik Bar',100.0,40000,'Modelo de Gelo e nicotina junto',ARRAY['Uva','Menta']::text[],'/pods/nik-bar-40-000.jpg',false,false,false,21),
('Blacksheep 30k','outras','Blacksheep',102.0,30000,'',ARRAY['Maçã verde / Uva e Blueberry','Morango e Banana / Abacaxi e Coco','Maçã verde / uva e blueberry']::text[],'/pods/blacksheep-30k.jpg',false,false,false,22),
('Airmez 50k','outras','Airmez',105.0,50000,'Pod com fone bluetooth',ARRAY['Menta','Banana','Melancia','Morango']::text[],'/pods/airmez-50k.jpg',false,false,false,23),
('Dinner 50k','outras','Dinner',115.0,50000,'',ARRAY['Melancia / Blueberry e menta','Menta gelada / Abacaxi','Banana / Pêssego, Manga e Melancia','Melancia gelada / Morango gelada','Uva / Menta']::text[],'/pods/dinner-50k.jpg',false,false,false,24),
('Dinner 60.000','outras','Dinner',120.0,60000,'',ARRAY['Menta','Cereja','Morango','Bala de Uva','Manga e Abacaxi']::text[],'/pods/dinner-60-000.jpg',true,false,false,25),
('Waka 70k','waka','Waka',120.0,70000,'Dual mode: vape ou pod',ARRAY['Uva','Menta','Cereja','Morango e kiwi']::text[],'/pods/waka-70k.jpg',false,false,false,26),
('Ignite V600 (600 puffs)','ignite','Ignite',35.0,600,'','{}'::text[],'/pods/ignite-v600-600-puffs.jpg',false,true,false,27),
('Ignite V10 (1.000 puffs)','ignite','Ignite',45.0,1000,'',ARRAY['Morango e Goiaba','Maracujá e Kiwi','Morango gelado','Menta gelada','Uva']::text[],'/pods/ignite-v10-1-000-puffs.jpg',false,false,false,28),
('Ignite V35 (3.500 puffs)','ignite','Ignite',50.0,3500,'','{}'::text[],'/pods/ignite-v35-3-500-puffs.jpg',false,true,false,29),
('Ignite V55 (5.500 puffs)','ignite','Ignite',75.0,5500,'',ARRAY['Menta','Morango gelado','Morango e Kiwi','Morango e Melancia','Blueberry','Uva']::text[],'/pods/ignite-v55-5-500-puffs.jpg',true,false,false,30),
('Ignite V80','ignite','Ignite',85.0,8000,'',ARRAY['Morango gelado','Maçã','Blueberry','Uva','Limão e Manga','Melancia','Banana e Cereja']::text[],'/pods/ignite-v80.jpg',false,false,false,31),
('Ignite V120','ignite','Ignite',85.0,12000,'',ARRAY['Romã e limão','Blueberry e Menta','Uva verde']::text[],'/pods/ignite-v120.jpg',false,false,false,32),
('Ignite V150','ignite','Ignite',85.0,15000,'',ARRAY['Maçã verde','Morango, Maçã e Melancia','Menthol','Uva']::text[],'/pods/ignite-v150.jpg',false,false,false,33),
('Ignite Frozen 20k','ignite','Ignite',90.0,20000,'',ARRAY['Menta','Morango','Melancia','Uva']::text[],'/pods/ignite-frozen-20k.jpg',false,false,false,34),
('Ignite V155 Ultra','ignite','Ignite',90.0,15000,'',ARRAY['Blueberry gelado','Banana gelada','Tropical e açaí','Melancia e pitaya','Morango e banana','Melancia gelado','Menta','Maçã Verde','Morango e Kiwi']::text[],'/pods/ignite-v155-ultra.jpg',true,false,false,35),
('Ignite V250 (25k)','ignite','Ignite',95.0,25000,'Cores aleatórias',ARRAY['Menta gelada','Morango gelado','Blueberry gelada','Maçã verde','Melancia gelada','Morango e Kiwi','Pêssego e Manga']::text[],'/pods/ignite-v250-25k.jpg',false,false,false,36),
('Ignite V300 Ultra 30.000','ignite','Ignite',103.0,30000,'',ARRAY['Banana gelada','Blueberry','Doce de romã','Menta e Melão','Morango e Kiwi','Blueberry, Morango e coco','Uva gelado','Abacaxi, Kiwi e Pitaya','Melancia e Pitaya','Abacaxi e Manga','Melancia gelado','Banana e Água de Coco','Morango e banana']::text[],'/pods/ignite-v300-ultra-30-000.jpg',false,false,false,37),
('Ignite V400 Mix 40.000','ignite','Ignite',115.0,40000,'Função ICE',ARRAY['Maçã / morango e melancia','Maracujá kiwi / abacaxi','Manga / maracujá goiaba','Uva / melancia']::text[],'/pods/ignite-v400-mix-40-000.jpg',false,false,false,38),
('Elfbar Touch 20.000','elfbar','Elfbar',70.0,20000,'',ARRAY['Limonada rosa','Cereja pêssego e limão','Pêssego e amora']::text[],'/pods/elfbar-touch-20-000.jpg',false,false,false,39),
('Elfbar 15.000','elfbar','Elfbar',75.0,15000,'',ARRAY['Abacaxi','Uva','Maracujá, Kiwi e Goiaba','Menta gelada','Blueberry']::text[],'/pods/elfbar-15-000.jpg',true,false,false,40),
('Elfbar BC 10.000','elfbar','Elfbar',75.0,10000,'',ARRAY['Menta gelada','Maçã verde','Kiwi, Melancia e Maçã','Pera, Melancia e Pitaya','Abacaxi, Morango e Banana']::text[],'/pods/elfbar-bc-10-000.jpg',false,false,false,41),
('Elfbar BC 25.000','elfbar','Elfbar',80.0,25000,'',ARRAY['Cereja, pêssego e limonada','Menta','Suco de manga']::text[],'/pods/elfbar-bc-25-000.jpg',false,false,false,42),
('Elfbar Shisha 18.000','elfbar','Elfbar',85.0,18000,'Pod estilo vape',ARRAY['Blueberry gelado','Limão gelado','Uva','Morango e melancia']::text[],'/pods/elfbar-shisha-18-000.jpg',false,false,false,43),
('Elfbar 23.000','elfbar','Elfbar',95.0,23000,'',ARRAY['Limão e Laranja','Menta','Maçã verde']::text[],'/pods/elfbar-23-000.jpg',false,false,false,44),
('Elfbar 30k','elfbar','Elfbar',95.0,30000,'',ARRAY['Love 66','Açaí e Banana gelado','Bubbaloo tutti frutti','Menta','Blueberry','Morango e Melancia','Morango e Pêssego','Abacaxi','Abacaxi e Mango','Pêssego, Manga e Melancia']::text[],'/pods/elfbar-30k.jpg',false,false,false,45),
('Elfbar Duke 35k','elfbar','Elfbar',100.0,35000,'',ARRAY['Morango e kiwi gelado','Morango e coco gelado','Uva gelada','Abacaxi','Blueberry']::text[],'/pods/elfbar-duke-35k.jpg',false,false,false,46),
('Elfbar 40.000 Trio Modo','elfbar','Elfbar',105.0,40000,'Modos: azedo, doce, gelado',ARRAY['Menta','Amora','Laranja','Blueberry','Uva','Morango, Laranja e limão']::text[],'/pods/elfbar-40-000-trio-modo.jpg',false,false,false,47),
('Elfbar 40.000 King','elfbar','Elfbar',105.0,40000,'Função pedra/gelo',ARRAY['Tropical doce','Cereja','3 Amora','Menta','Blueberry e framboesa','Maçã','Tropical','Bala fini azedinho','Morango, Maçã e Melancia','Morango gelado','Manga','Maracujá','Cereja, Pêssego e limonada','Suco de morango']::text[],'/pods/elfbar-40-000-king.jpg',false,false,false,48),
('Elfbar 33k','elfbar','Elfbar',110.0,33000,'',ARRAY['Cereja, Romã e Abacaxi','Soda e Pera','Maçã e Kiwi']::text[],'/pods/elfbar-33k.jpg',false,false,false,49),
('Elfbar BC PRO 45.000','elfbar','Elfbar',115.0,45000,'',ARRAY['Morango','Abacaxi','Uva','Blueberry, Morango e Coco','Melancia','Morango e Kiwi','Frutas Tropicais']::text[],'/pods/elfbar-bc-pro-45-000.jpg',false,false,false,50),
('Elfbar EW Cartucho 16k','elfbar','Elfbar',78.0,16000,'Só funciona com bateria',ARRAY['Morango gelado','Amora e Blueberry','Morango e kiwi']::text[],'/pods/elfbar-ew-cartucho-16k.jpg',false,false,true,51),
('Elfbar EW Cartucho 9k + Bateria','elfbar','Elfbar',75.0,9000,'Só funciona com bateria',ARRAY['Pitaya, morango e banana','Blueberry e framboesa']::text[],'/pods/elfbar-ew-cartucho-9k-bateria.jpg',false,false,true,52),
('Elfbar EW Cartucho 9k','elfbar','Elfbar',57.0,9000,'Só funciona com bateria','{}'::text[],'/pods/elfbar-ew-cartucho-9k.jpg',false,true,true,53),
('Oxbar 30.000','oxbar','Oxbar',85.0,30000,'',ARRAY['Framboesa e Limão','Manga','Blueberry, Framboesa e Limão','Melancia e Limão','Abacaxi e coco','Uva Branca']::text[],'/pods/oxbar-30-000.jpg',false,false,false,54),
('Oxbar 50.000','oxbar','Oxbar',115.0,50000,'',ARRAY['Menta','Menthol','Morango','Abacaxi kiwi e pitaya','Maracujá e kiwi','Uva']::text[],'/pods/oxbar-50-000.jpg',false,false,false,55),
('Oxbar 32.000 Cartucho','oxbar','Oxbar',85.0,32000,'Só funciona com bateria · Kit cartucho + bateria R$ 130 · 2 cartuchos + bateria de brinde R$ 185',ARRAY['Menta','Morango kiwi gelado','Morango melancia gelada','Paraíso da uva','Maçã kiwi gelado','Três manga gelada']::text[],'/pods/oxbar-32-000-cartucho.jpg',false,false,true,56);