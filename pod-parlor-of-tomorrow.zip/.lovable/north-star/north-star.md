<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Clientes compram os pods que querem na Crazy Pods

## Métrica

Pessoas que fazem um pedido de pods com a loja a cada semana
