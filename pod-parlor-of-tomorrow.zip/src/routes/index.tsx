import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ShieldCheck, Truck, CreditCard, Headphones, Zap, ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import heroBannerImg from "@/assets/dinner-lady-luma-40k-prata.jpg";
import { productsQuery, type Product } from "@/lib/products";
import { ShopShell, useShop, useReveal, brandCats, extraCats, match, ProductGrid, WhatsAppIcon, useSettings } from "@/components/shop";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Crazy Pods — Pods originais com entrega rápida" },
      { name: "description", content: "Os melhores pods descartáveis: Elfbar, Lost Mary, Ignite e mais. Escolha por marca ou puffs, entrega rápida em Osasco e SP." },
      { property: "og:title", content: "Crazy Pods — Pods originais" },
      { property: "og:description", content: "Pods descartáveis originais com entrega rápida." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <ShopShell><Home /></ShopShell>,
});

const brands = ["IGNITE", "ELFBAR", "LOST MARY", "OXBAR", "WAKA", "GEEK BAR", "NIK BAR", "DINNER", "DOJO", "RABBEATS", "BLACKSHEEP"];
const SPOT_NAMES = ["Ignite V155 Ultra", "Geek Bar 35.000", "Waka 50.000", "Elfbar 15.000"];

function Home() {
  const { data: catalog = [] } = useQuery(productsQuery);
  useReveal(catalog.length);
  const { openPod } = useShop();
  const { s: settings, WA } = useSettings();
  const [spot, setSpot] = useState(0);
  useEffect(() => { const t = setInterval(() => setSpot((s) => (s + 1) % 100), 4000); return () => clearInterval(t); }, []);
  const spots = (settings.featuredIds.length ? settings.featuredIds.map((id) => catalog.find((p) => p.id === id)) : SPOT_NAMES.map((n) => catalog.find((p) => p.name === n))).filter((p): p is Product => !!p && !!p.image);
  const cur = spots[spot % Math.max(1, spots.length)];
  const launches = catalog.map((p, i) => ({ p, i })).filter(({ p }) => p.launch && !p.soldout).slice(0, 4);

  return (
    <>
      <section className="relative isolate overflow-hidden">
        <button onClick={() => { const i = settings.heroProductId ? catalog.findIndex((x) => x.id === settings.heroProductId) : catalog.findIndex((x) => /luma 40k/i.test(x.name)); if (i >= 0) openPod(catalog[i]!, i); }} aria-label="Ver lançamento em destaque" className="block w-full">
          <img src={settings.heroImage ?? heroBannerImg} alt="Lançamento em destaque na Crazy Pods" width={1672} height={941} className="mx-auto block h-auto w-full max-w-[1920px] animate-rise" />
        </button>
      </section>

      <section className="relative z-10 mx-auto mt-6 max-w-7xl px-5">
        <div className="glass grid grid-cols-2 gap-4 rounded-2xl p-5 md:grid-cols-4">
          {[[Truck, "Entrega rápida", "Osasco e região de SP"], [ShieldCheck, "Originais", "Procedência garantida"], [CreditCard, "Pagamento fácil", "Pix ou cartão"], [Headphones, "Suporte", "Atendimento humano"]].map(([I, t, d]) => {
            const Ic = I as typeof Zap;
            return <div key={t as string} className="flex items-center gap-3"><div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-secondary"><Ic className="h-5 w-5 text-primary-glow" /></div><div><p className="text-sm font-bold">{t as string}</p><p className="text-xs text-muted-foreground">{d as string}</p></div></div>;
          })}
        </div>
      </section>

      {/* big entry: all pods */}
      <section className="mx-auto max-w-7xl px-5 pt-20">
        <Link to="/pods" className="reveal group relative block overflow-hidden rounded-3xl border border-border bg-gradient-card p-8 transition duration-500 hover:shadow-glow md:p-12">
          <div className="absolute inset-0 grid-bg opacity-40" />
          <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="font-display text-xs tracking-[0.4em] text-primary-glow">CATÁLOGO COMPLETO</p>
              <h2 className="mt-3 font-display text-3xl font-black md:text-5xl">Ver todos os <span className="text-gradient">pods</span></h2>
              <p className="mt-2 text-muted-foreground">{catalog.length} modelos, todos os sabores, num só lugar.</p>
            </div>
            <span className="flex items-center gap-2 rounded-full bg-gradient-primary px-7 py-4 font-bold text-primary-foreground shadow-glow transition group-hover:scale-105">Explorar catálogo <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" /></span>
          </div>
          <div className="pointer-events-none relative mt-8 flex justify-center gap-4">
            {catalog.filter((p) => p.image).slice(0, 5).map((p, k) => <img key={p.id} src={p.image!} alt="" className="pod-fly h-24 w-16 animate-float object-contain md:h-32 md:w-20" style={{ animationDelay: `${k * 300}ms` }} />)}
          </div>
        </Link>
      </section>

      {/* brands */}
      <section className="mx-auto max-w-7xl px-5 pt-20">
        <h2 className="reveal font-display text-3xl font-bold md:text-4xl">Escolha por <span className="text-gradient">marca</span></h2>
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          {brandCats.map((c, i) => (
            <Link key={c.id} to="/categoria/$cat" params={{ cat: c.id }}
              className="reveal group relative h-48 overflow-hidden rounded-2xl border border-border bg-gradient-card p-5 text-left transition duration-500 hover:-translate-y-2 hover:shadow-glow" style={{ transitionDelay: `${i * 70}ms` }}>
              <div className="absolute -right-6 -top-6 h-32 w-32 rounded-full bg-primary/30 blur-2xl transition group-hover:bg-primary-glow/50" />
              {c.logo ? <img src={c.logo} alt={c.label} loading="lazy" className="absolute inset-x-5 top-6 mx-auto h-24 w-[calc(100%-2.5rem)] object-contain brightness-0 invert drop-shadow-[0_0_12px_hsl(0_0%_100%/0.35)] transition duration-500 group-hover:scale-110" /> : <p className="absolute inset-x-5 top-10 text-center font-display text-2xl font-black leading-tight text-muted-foreground transition group-hover:text-foreground">+ MARCAS</p>}
              <div className="absolute bottom-5 left-5">
                <p className="flex items-center gap-1 text-xs text-muted-foreground">{catalog.filter((p) => match(p, c.id)).length} modelos <ArrowRight className="h-3 w-3 transition group-hover:translate-x-1" /></p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* by style */}
      <section className="mx-auto max-w-7xl px-5 pt-20">
        <h2 className="reveal font-display text-3xl font-bold md:text-4xl">Escolha pelo seu <span className="text-gradient">estilo</span></h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {extraCats.map((c, i) => (
            <Link key={c.id} to="/categoria/$cat" params={{ cat: c.id }} className="reveal group glass flex flex-col gap-3 rounded-2xl p-6 transition duration-500 hover:-translate-y-1 hover:shadow-glow" style={{ transitionDelay: `${i * 70}ms` }}>
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-secondary transition group-hover:bg-gradient-primary"><c.icon className="h-6 w-6 text-primary-glow group-hover:text-primary-foreground" /></div>
              <p className="font-display font-bold">{c.label}</p>
              <p className="text-xs text-muted-foreground">{c.desc}</p>
              <p className="mt-auto flex items-center gap-1 text-xs font-semibold">{catalog.filter((p) => match(p, c.id)).length} modelos <ArrowRight className="h-3 w-3 transition group-hover:translate-x-1" /></p>
            </Link>
          ))}
        </div>
      </section>

      {/* spotlight */}
      {cur && (
        <section className="mx-auto max-w-7xl px-5 pt-20">
          <div className="reveal relative overflow-hidden rounded-3xl border border-border bg-gradient-card p-8 md:p-14">
            <div className="absolute inset-0 grid-bg opacity-50" />
            <div className="relative grid items-center gap-10 md:grid-cols-2">
              <div key={spot} className="animate-rise">
                <p className="font-display text-xs tracking-[0.4em] text-primary-glow">EM DESTAQUE</p>
                <h3 className="mt-3 font-display text-4xl font-black md:text-5xl">{cur.name.toUpperCase()}</h3>
                <p className="mt-2 text-lg text-muted-foreground">{cur.flavors.length} sabores</p>
                <div className="mt-8 grid grid-cols-3 gap-3">
                  {[[`${Math.round(cur.puffs / 1000)}k`, "puffs"], [String(cur.flavors.length), "sabores"], [`R$ ${cur.price}`, "preço"]].map(([v, l]) => <div key={l} className="glass rounded-xl p-4 text-center"><p className="font-display text-2xl font-bold text-gradient">{v}</p><p className="text-xs text-muted-foreground">{l}</p></div>)}
                </div>
                <button onClick={() => openPod(cur, catalog.indexOf(cur))} className="mt-6 rounded-full bg-gradient-primary px-6 py-3 font-bold text-primary-foreground shadow-glow">Ver sabores</button>
                <div className="mt-8 flex gap-2">{spots.map((_, i) => <button key={i} aria-label={`Destaque ${i + 1}`} onClick={() => setSpot(i)} className={`h-1.5 rounded-full transition-all ${i === spot % spots.length ? "w-10 bg-gradient-primary" : "w-4 bg-secondary"}`} />)}</div>
              </div>
              <div className="relative grid h-[420px] place-items-center">
                <div className="absolute h-72 w-72 animate-pulse-glow rounded-full bg-primary/40 blur-3xl" />
                <div className="absolute h-80 w-80 rounded-full border border-border" />
                <img key={spot} src={cur.image!} alt={cur.name} width={1024} height={1024} className="pod-fly relative h-[400px] w-[400px] animate-float object-contain" />
              </div>
            </div>
          </div>
        </section>
      )}

      {/* launches preview */}
      {launches.length > 0 && (
        <section className="mx-auto max-w-7xl px-5 pt-20">
          <div className="flex items-end justify-between gap-4">
            <h2 className="reveal font-display text-3xl font-bold md:text-4xl">Acabou de <span className="text-gradient">chegar</span></h2>
            <Link to="/categoria/$cat" params={{ cat: "lancamentos" }} className="flex shrink-0 items-center gap-1 text-sm font-semibold text-muted-foreground hover:text-foreground">Ver todos <ArrowRight className="h-4 w-4" /></Link>
          </div>
          <div className="mt-8"><ProductGrid list={launches} /></div>
        </section>
      )}

      <section className="mt-20 overflow-hidden border-y border-border bg-muted/40 py-8">
        <div className="flex w-max animate-marquee gap-16">
          {[...brands, ...brands].map((b, i) => <span key={i} className="font-display text-3xl font-black text-muted-foreground/40 md:text-5xl">{b}</span>)}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pt-20">
        <div className="reveal relative overflow-hidden rounded-3xl bg-gradient-primary p-10 text-center md:p-16">
          <div className="absolute inset-0 grid-bg opacity-30" />
          <h2 className="relative font-display text-3xl font-black text-primary-foreground md:text-5xl">{settings.ctaTitle}</h2>
          <p className="relative mx-auto mt-4 max-w-md text-primary-foreground/80">{settings.ctaText}</p>
          <a href={WA} target="_blank" rel="noopener noreferrer" className="relative mt-8 inline-flex items-center gap-2 rounded-full bg-whatsapp px-8 py-4 font-bold text-primary-foreground transition hover:scale-105"><WhatsAppIcon className="h-5 w-5" />Falar com a Crazy Pods</a>
        </div>
      </section>
    </>
  );
}
