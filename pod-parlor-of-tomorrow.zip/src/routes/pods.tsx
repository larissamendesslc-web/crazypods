import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { productsQuery } from "@/lib/products";
import { ShopShell, ProductGrid, allCats, match, type Cat } from "@/components/shop";

export const Route = createFileRoute("/pods")({
  validateSearch: (s: Record<string, unknown>): { q?: string | undefined } => ({ q: typeof s["q"] === "string" && s["q"] ? s["q"] : undefined }),
  head: () => ({
    meta: [
      { title: "Todos os pods — Crazy Pods" },
      { name: "description", content: "Catálogo completo de pods descartáveis Crazy Pods: todas as marcas, puffs e sabores." },
      { property: "og:title", content: "Todos os pods — Crazy Pods" },
      { property: "og:description", content: "Catálogo completo com todas as marcas e sabores." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <ShopShell><AllPods /></ShopShell>,
});

function AllPods() {
  const { q } = Route.useSearch();
  const { data: catalog = [] } = useQuery(productsQuery);
  const [query, setQuery] = useState(q ?? "");
  const [cat, setCat] = useState<Cat | "todos">("todos");
  const list = useMemo(() => catalog.map((p, i) => ({ p, i }))
    .filter(({ p }) => match(p, cat) && `${p.name} ${p.brand} ${p.flavors.join(" ")}`.toLowerCase().includes(query.toLowerCase()))
    .sort((a, b) => Number(a.p.soldout) - Number(b.p.soldout)), [catalog, cat, query]);
  return (
    <section className="mx-auto max-w-7xl px-5 pt-12">
      <p className="text-sm text-muted-foreground"><Link to="/" className="hover:text-foreground">Início</Link> / Todos os pods</p>
      <h1 className="mt-3 font-display text-4xl font-black md:text-5xl">Todos os <span className="text-gradient">pods</span> <span className="text-base font-medium text-muted-foreground">· {list.length}</span></h1>
      <div className="mt-6 flex items-center gap-2 rounded-full bg-secondary px-4 py-3 md:max-w-md">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar pods, sabores..." className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground" />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {[{ id: "todos" as const, label: "Todos" }, ...allCats].map((c) => (
          <button key={c.id} onClick={() => setCat(c.id)} className={`rounded-full px-4 py-2 text-sm font-semibold transition ${cat === c.id ? "bg-gradient-primary text-primary-foreground shadow-glow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>{c.label}</button>
        ))}
      </div>
      <div className="mt-8"><ProductGrid list={list} /></div>
    </section>
  );
}
