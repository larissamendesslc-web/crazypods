import logo from "@/assets/crazy-pods-logo.png.asset.json";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — Crazy Pods Admin" },
      { name: "description", content: "Acesso à área administrativa da Crazy Pods." },
      { property: "og:title", content: "Entrar — Crazy Pods Admin" },
      { property: "og:description", content: "Acesso à área administrativa da Crazy Pods." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

const ADMIN_USERS: Record<string, string> = { admin: "jliveira56@gmail.com" };

function AuthPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => { if (data.user) navigate({ to: "/admin" }); });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const email = ADMIN_USERS[user.trim().toLowerCase()];
    if (!email || !password) { toast.error("Usuário ou senha incorretos."); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) { toast.error("Usuário ou senha incorretos."); return; }
    navigate({ to: "/admin" });
  };

  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="absolute inset-0 -z-10 grid-bg opacity-40" />
      <form onSubmit={submit} className="glass w-full max-w-sm rounded-3xl p-8 shadow-glow">
        <Link to="/" className="block shrink-0"><img src={logo.url} alt="Crazy Pods" width={56} height={56} className="h-14 w-14 rounded-xl object-cover" /></Link>
        <h1 className="mt-6 font-display text-2xl font-bold">Entrar no painel</h1>
        <p className="mt-1 text-sm text-muted-foreground">Área administrativa da loja.</p>
        <label className="mt-6 block text-sm font-semibold">Usuário</label>
        <input autoComplete="username" value={user} onChange={(e) => setUser(e.target.value)} className="mt-1 w-full rounded-xl border border-input bg-secondary px-4 py-3 outline-none focus:border-primary" />
        <label className="mt-4 block text-sm font-semibold">Senha</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 w-full rounded-xl border border-input bg-secondary px-4 py-3 outline-none focus:border-primary" />
        <button disabled={loading} className="mt-6 w-full rounded-full bg-gradient-primary py-3 font-bold text-primary-foreground transition hover:scale-[1.02] disabled:opacity-60">
          {loading ? "Aguarde..." : "Entrar"}
        </button>
      </form>
    </div>
  );
}
