import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { productsQuery } from "@/lib/products";
import { ShopShell, ProductGrid, allCats, brandCats, extraCats, catLabel, match, type Cat } from "@/components/shop";

export const Route = createFileRoute("/categoria/$cat")({
  loader: ({ params }) => { const label = catLabel(params.cat); if (!label) throw notFound(); return { label }; },
  head: ({ loaderData }) => {
    const l = loaderData?.label ?? "Categoria";
    return { meta: [
      { title: `${l} — Crazy Pods` },
      { name: "description", content: `Pods ${l} originais na Crazy Pods: escolha o sabor e peça pelo WhatsApp.` },
      { property: "og:title", content: `${l} — Crazy Pods` },
      { property: "og:description", content: `Veja os pods ${l} disponíveis na Crazy Pods.` },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ] };
  },
  notFoundComponent: () => <ShopShell><div className="py-32 text-center"><p className="font-display text-2xl font-bold">Categoria não encontrada</p><Link to="/pods" className="mt-4 inline-block text-primary-glow">Ver todos os pods</Link></div></ShopShell>,
  component: () => <ShopShell><CategoryPage /></ShopShell>,
});

function CategoryPage() {
  const { cat } = Route.useParams();
  const id = cat as Cat;
  const { data: catalog = [] } = useQuery(productsQuery);
  const brand = brandCats.find((c) => c.id === id);
  const extra = extraCats.find((c) => c.id === id);
  const list = catalog.map((p, i) => ({ p, i })).filter(({ p }) => match(p, id)).sort((a, b) => Number(a.p.soldout) - Number(b.p.soldout));
  const Icon = extra?.icon;
  return (
    <>
      <section key={id} className="relative overflow-hidden border-b border-border bg-gradient-card">
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="relative mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 py-12 md:py-16">
          <div className="animate-rise">
            <p className="text-sm text-muted-foreground"><Link to="/" className="hover:text-foreground">Início</Link> / {catLabel(id)}</p>
            <h1 className="mt-3 font-display text-4xl font-black md:text-6xl"><span className="text-gradient">{catLabel(id)}</span></h1>
            <p className="mt-3 text-muted-foreground">{extra?.desc ?? `Todos os modelos ${brand?.label} originais`} · {list.length} modelos</p>
          </div>
          {brand && <img src={brand.img} alt="" className="pod-fly h-40 w-40 animate-float object-contain md:h-56 md:w-56" />}
          {Icon && <div className="grid h-28 w-28 animate-pulse-glow place-items-center rounded-3xl bg-secondary md:h-36 md:w-36"><Icon className="h-14 w-14 text-primary-glow" /></div>}
        </div>
      </section>
      <nav className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-5 pt-6">
        {allCats.map((c) => (
          <Link key={c.id} to="/categoria/$cat" params={{ cat: c.id }} className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition ${c.id === id ? "bg-gradient-primary text-primary-foreground shadow-glow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>{c.label}</Link>
        ))}
      </nav>
      <section className="mx-auto max-w-7xl px-5 pt-8"><ProductGrid list={list} /></section>
      <div className="mt-12 text-center"><Link to="/pods" className="inline-flex items-center gap-2 rounded-full bg-secondary px-6 py-3 font-semibold hover:shadow-glow">Ver todos os pods <ArrowRight className="h-4 w-4" /></Link></div>
    </>
  );
}
