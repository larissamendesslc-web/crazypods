import { supabase } from "@/integrations/supabase/client";

/** Uploads an image to the private pod-images bucket and returns a 10-year signed URL.
 *  With removeBg, the background is removed in the browser first (transparent PNG). */
export async function uploadImage(file: File, removeBg: boolean): Promise<string> {
  let blob: Blob = file;
  let ext = file.name.split(".").pop() || "jpg";
  if (removeBg) {
    const { removeBackground } = await import("@imgly/background-removal");
    blob = await removeBackground(file, { output: { format: "image/png" } });
    blob = await trimTransparent(blob);
    ext = "png";
  }
  const path = `${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from("pod-images").upload(path, blob, { contentType: blob.type || file.type });
  if (error) throw error;
  const { data, error: e2 } = await supabase.storage.from("pod-images").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
  if (e2 || !data) throw e2 ?? new Error("signed url");
  return data.signedUrl;
}

/** Crops empty transparent borders and caps size at 700px, matching the catalog cutouts. */
async function trimTransparent(blob: Blob): Promise<Blob> {
  const img = await createImageBitmap(blob);
  const c = document.createElement("canvas"); c.width = img.width; c.height = img.height;
  const ctx = c.getContext("2d")!; ctx.drawImage(img, 0, 0);
  const { data } = ctx.getImageData(0, 0, c.width, c.height);
  let x0 = c.width, y0 = c.height, x1 = 0, y1 = 0;
  for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) if (data[(y * c.width + x) * 4 + 3]! > 10) { if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; }
  if (x1 <= x0 || y1 <= y0) return blob;
  const w = x1 - x0 + 1, h = y1 - y0 + 1, s = Math.min(1, 700 / Math.max(w, h));
  const o = document.createElement("canvas"); o.width = Math.round(w * s); o.height = Math.round(h * s);
  o.getContext("2d")!.drawImage(c, x0, y0, w, h, 0, 0, o.width, o.height);
  return await new Promise((r) => o.toBlob((b) => r(b ?? blob), "image/png"));
}
