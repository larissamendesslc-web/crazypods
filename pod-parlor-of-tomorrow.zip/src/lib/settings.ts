import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type SiteSettings = {
  heroImage: string | null;
  heroProductId: string | null;
  marquee: string[];
  whatsapp: string;
  whatsappMessage: string;
  ctaTitle: string;
  ctaText: string;
  featuredIds: string[];
};

export const DEFAULT_SETTINGS: SiteSettings = {
  heroImage: null,
  heroProductId: null,
  marquee: ["Entrega rápida em Osasco e região de SP", "Pods 100% originais", "+5.000 clientes satisfeitos", "Pix com desconto"],
  whatsapp: "5511986825360",
  whatsappMessage: "Olá! Vim pelo site da Crazy Pods e quero comprar um pod.",
  ctaTitle: "Não achou seu sabor?",
  ctaText: "Fala com a gente no WhatsApp e a gente encontra o pod perfeito pra você.",
  featuredIds: [],
};

export const settingsQuery = queryOptions({
  queryKey: ["site_settings"],
  queryFn: async (): Promise<SiteSettings> => {
    const { data } = await supabase.from("site_settings").select("data").eq("id", 1).maybeSingle();
    return { ...DEFAULT_SETTINGS, ...((data?.data as Partial<SiteSettings>) ?? {}) };
  },
});

export const waBase = (s: SiteSettings) => `https://wa.me/${s.whatsapp.replace(/\D/g, "")}?text=`;
