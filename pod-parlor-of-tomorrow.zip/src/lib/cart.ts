export type CartItem = { id: string; name: string; flavor: string | null; price: number; qty: number };

export const brlFmt = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const cartKey = (i: Pick<CartItem, "id" | "flavor">) => `${i.id}::${i.flavor ?? ""}`;
export const cartTotal = (items: CartItem[]) => items.reduce((s, i) => s + i.price * i.qty, 0);
export const cartCount = (items: CartItem[]) => items.reduce((s, i) => s + i.qty, 0);

export function addToCart(items: CartItem[], item: CartItem): CartItem[] {
  const k = cartKey(item);
  const found = items.find((i) => cartKey(i) === k);
  if (found) return items.map((i) => (cartKey(i) === k ? { ...i, qty: i.qty + item.qty } : i));
  return [...items, item];
}

export function setQty(items: CartItem[], key: string, qty: number): CartItem[] {
  return qty <= 0 ? items.filter((i) => cartKey(i) !== key) : items.map((i) => (cartKey(i) === key ? { ...i, qty } : i));
}

export function cartMessage(items: CartItem[]): string {
  const lines = items.map((i, n) => `${n + 1}. ${i.qty}x ${i.name}${i.flavor ? ` — sabor ${i.flavor}` : ""} (${brlFmt(i.price)} cada = ${brlFmt(i.price * i.qty)})`);
  return ["Olá! Vim pelo site da Crazy Pods e quero fazer este pedido:", "", ...lines, "", `*Total: ${brlFmt(cartTotal(items))}* (${cartCount(items)} ${cartCount(items) === 1 ? "item" : "itens"})`].join("\n");
}
