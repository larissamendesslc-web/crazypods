import { describe, it, expect } from "vitest";
import { addToCart, cartMessage, cartTotal, setQty, cartKey } from "./cart";

const a = { id: "1", name: "Ignite V155", flavor: "Uva", price: 90, qty: 1 };
describe("carrinho", () => {
  it("soma quantidade do mesmo pod e sabor", () => {
    expect(addToCart([a], { ...a, qty: 2 })[0]!.qty).toBe(3);
  });
  it("sabores diferentes viram itens separados", () => {
    expect(addToCart([a], { ...a, flavor: "Menta" })).toHaveLength(2);
  });
  it("total considera preço x quantidade de todos os itens", () => {
    expect(cartTotal([{ ...a, qty: 2 }, { id: "2", name: "Waka", flavor: null, price: 110, qty: 1 }])).toBe(290);
  });
  it("quantidade zero remove o item", () => {
    expect(setQty([a], cartKey(a), 0)).toHaveLength(0);
  });
  it("mensagem lista cada item com sabor e o total", () => {
    const m = cartMessage([{ ...a, qty: 2 }]);
    expect(m).toContain("2x Ignite V155 — sabor Uva");
    expect(m).toContain("Total: R$");
    expect(m).toContain("180,00");
  });
});
