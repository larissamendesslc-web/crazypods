import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Upload, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { settingsQuery, DEFAULT_SETTINGS, type SiteSettings } from "@/lib/settings";
import { productsQuery } from "@/lib/products";
import { uploadImage } from "@/lib/upload";
import heroDefault from "@/assets/dinner-lady-luma-40k-prata.jpg";

const input = "mt-1 w-full rounded-xl border border-input bg-secondary px-4 py-2.5 text-sm outline-none focus:border-primary";

export function AdminSettings() {
  const qc = useQueryClient();
  const { data } = useQuery(settingsQuery);
  const { data: products = [] } = useQuery(productsQuery);
  const [s, setS] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  useEffect(() => { if (data) setS(data); }, [data]);
  const set = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => setS((x) => ({ ...x, [k]: v }));

  const save = async () => {
    if (s.whatsapp.replace(/\D/g, "").length < 12) { toast.error("WhatsApp deve ter DDI + DDD + número, ex: 5511986825360"); return; }
    setSaving(true);
    const { error } = await supabase.from("site_settings").upsert({ id: 1, data: s, updated_at: new Date().toISOString() });
    setSaving(false);
    if (error) { toast.error("Não foi possível salvar."); return; }
    toast.success("Site atualizado!");
    qc.invalidateQueries({ queryKey: ["site_settings"] });
  };
  const uploadHero = async (f: File) => {
    setUploading(true);
    try { set("heroImage", await uploadImage(f, false)); toast.success("Banner enviado. Clique em Salvar."); }
    catch { toast.error("Falha ao enviar o banner."); }
    setUploading(false);
  };
  const toggleFeatured = (id: string) => set("featuredIds", s.featuredIds.includes(id) ? s.featuredIds.filter((x) => x !== id) : [...s.featuredIds, id]);
  const card = "rounded-2xl border border-border bg-gradient-card p-6";

  return (
    <div className="space-y-6">
      <section className={card}>
        <h2 className="font-display text-xl font-bold">Banner principal</h2>
        <p className="text-sm text-muted-foreground">Imagem grande do topo da loja. Tamanho ideal: 1672 × 940 px.</p>
        <div className="mt-4 grid gap-4 md:grid-cols-[2fr_1fr]">
          <label className="relative block cursor-pointer overflow-hidden rounded-xl border border-dashed border-border">
            <img src={s.heroImage ?? heroDefault} alt="Banner atual" className="aspect-[16/9] w-full object-cover" />
            <span className="absolute bottom-3 left-3 flex items-center gap-2 rounded-full bg-background/80 px-4 py-2 text-sm font-semibold"><Upload className="h-4 w-4" />{uploading ? "Enviando..." : "Trocar banner"}</span>
            <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && uploadHero(e.target.files[0])} />
          </label>
          <div>
            <label className="text-sm font-semibold">Ao clicar no banner, abrir o pod:
              <select className={input} value={s.heroProductId ?? ""} onChange={(e) => set("heroProductId", e.target.value || null)}>
                <option value="">Dinner Lady Luma 40K (padrão)</option>
                {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </label>
            {s.heroImage && <button onClick={() => set("heroImage", null)} className="mt-3 text-sm text-muted-foreground underline">Voltar ao banner original</button>}
          </div>
        </div>
      </section>

      <section className={card}>
        <h2 className="font-display text-xl font-bold">Pods em destaque</h2>
        <p className="text-sm text-muted-foreground">Escolha os pods que giram na seção "Em destaque" do início ({s.featuredIds.length} escolhidos). Sem nenhum escolhido, a loja usa uma seleção padrão.</p>
        <div className="mt-4 flex max-h-72 flex-wrap gap-2 overflow-y-auto">
          {products.map((p) => (
            <button key={p.id} onClick={() => toggleFeatured(p.id)} className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${s.featuredIds.includes(p.id) ? "border-primary bg-gradient-primary text-primary-foreground" : "border-border bg-secondary"}`}>
              {p.image && <img src={p.image} alt="" className="h-5 w-5 object-contain" />}{p.name}
            </button>
          ))}
        </div>
      </section>

      <section className={card}>
        <h2 className="font-display text-xl font-bold">Textos e WhatsApp</h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <label className="text-sm font-semibold">Número do WhatsApp (com 55 + DDD)<input className={input} value={s.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} placeholder="5511986825360" /></label>
          <label className="text-sm font-semibold">Mensagem inicial do WhatsApp<input className={input} value={s.whatsappMessage} onChange={(e) => set("whatsappMessage", e.target.value)} /></label>
          <label className="text-sm font-semibold">Título do convite final<input className={input} value={s.ctaTitle} onChange={(e) => set("ctaTitle", e.target.value)} /></label>
          <label className="text-sm font-semibold">Texto do convite final<input className={input} value={s.ctaText} onChange={(e) => set("ctaText", e.target.value)} /></label>
        </div>
        <p className="mt-5 text-sm font-semibold">Avisos da faixa do topo</p>
        <div className="mt-2 space-y-2">
          {s.marquee.map((t, i) => (
            <div key={i} className="flex gap-2">
              <input className={`${input} mt-0`} value={t} onChange={(e) => set("marquee", s.marquee.map((x, j) => (j === i ? e.target.value : x)))} />
              <button aria-label="Remover aviso" onClick={() => set("marquee", s.marquee.filter((_, j) => j !== i))} className="rounded-xl bg-secondary px-3"><X className="h-4 w-4" /></button>
            </div>
          ))}
          <button onClick={() => set("marquee", [...s.marquee, ""])} className="text-sm font-semibold text-primary-glow">+ Adicionar aviso</button>
        </div>
      </section>

      <div className="sticky bottom-4 flex justify-end">
        <button disabled={saving || uploading} onClick={save} className="rounded-full bg-gradient-primary px-10 py-4 font-bold text-primary-foreground shadow-glow disabled:opacity-60">{saving ? "Salvando..." : "Salvar alterações do site"}</button>
      </div>
    </div>
  );
}
