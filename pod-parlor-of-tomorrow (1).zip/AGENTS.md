<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

- Products live in the `products` table (public read, admin-only write via `has_role`); the storefront and `/admin` both read through `productsQuery` in `src/lib/products.ts`. Why: one source of truth editable from the admin panel.
- Public sign-up is disabled; the admin signs in at /auth with a username mapped to an email in `ADMIN_USERS` (src/routes/auth.tsx). Why: single-owner shop, no public accounts.
- Pod images uploaded in the admin go to the private `pod-images` bucket and are stored as 10-year signed URLs, because public buckets are blocked in this workspace. Seed images live in `public/pods/cut/` as transparent PNG cutouts (originals in `public/pods/`).
- The shopping cart is client-only (localStorage via src/lib/cart.ts) and checkout is a single WhatsApp message built by cartMessage. Why: orders are closed on WhatsApp; no payment/order backend.
- Editable site content (hero banner, hero pod, featured pods, marquee, WhatsApp, CTA) lives in the single-row `site_settings` table (jsonb `data`), read via `settingsQuery` merged over DEFAULT_SETTINGS. Why: owner edits the site from the admin without code changes.
- Product photos always pass through uploadPodImage for browser background removal and trimming to a 700px transparent PNG; banner uploads retain their artwork. Shared bg-product-stage and pod-fly tokens supply the display background and shadow, never baked into the photo. Why: current and future product photos match in the catalog, detail dialog, highlights and admin.
- Store catalog and category pages share CatalogBrowser for search, filters and sorting; use accessible Dialog/Sheet controls for purchases. Why: navigation stays consistent and keyboard users can complete the same flow.
- Each product stores photo scale and percentage offsets in products; photoStyle supplies shared CSS variables to PodImage and admin previews without altering the transparent file or standard shadow. Why: per-product framing persists consistently across screen sizes and storefront views.
- Admin operations use private inventory per product/flavor, immutable sale snapshots and separate cash entries. record_sale/cancel_sale authenticate admin roles and lock inventory in database transactions; confirmed sales alone count as receipts. Why: stock cannot go negative under concurrent sales and cancelled sales return stock without duplicating revenue.
- Storefront pages use a shared age-declaration gate before rendering ShopContent and remember acceptance in sessionStorage; admin pages are unaffected. Why: direct catalog/category entry requires the same declaration without treating it as identity verification.
