CREATE TABLE public.inventory (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE, flavor text NOT NULL DEFAULT '', quantity integer NOT NULL DEFAULT 0 CHECK(quantity>=0), low_stock integer NOT NULL DEFAULT 3 CHECK(low_stock>=0), UNIQUE(product_id,flavor));
GRANT SELECT,INSERT,UPDATE,DELETE ON public.inventory TO authenticated; GRANT ALL ON public.inventory TO service_role;
ALTER TABLE public.inventory ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admin inventory" ON public.inventory FOR ALL TO authenticated USING(public.has_role(auth.uid(),'admin')) WITH CHECK(public.has_role(auth.uid(),'admin'));
CREATE TABLE public.sales (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), customer text NOT NULL DEFAULT '', payment text NOT NULL CHECK(payment IN ('pix','cash','card','other')), total numeric(12,2) NOT NULL CHECK(total>=0), notes text NOT NULL DEFAULT '', status text NOT NULL DEFAULT 'completed' CHECK(status IN ('completed','cancelled')), sold_at timestamptz NOT NULL DEFAULT now(), created_by uuid NOT NULL);
GRANT SELECT ON public.sales TO authenticated; GRANT ALL ON public.sales TO service_role;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admin sales read" ON public.sales FOR SELECT TO authenticated USING(public.has_role(auth.uid(),'admin'));
CREATE TABLE public.sale_items (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), sale_id uuid NOT NULL REFERENCES public.sales(id), product_id uuid REFERENCES public.products(id) ON DELETE SET NULL, inventory_id uuid REFERENCES public.inventory(id) ON DELETE SET NULL, product_name text NOT NULL, flavor text NOT NULL DEFAULT '', quantity integer NOT NULL CHECK(quantity>0), unit_price numeric(12,2) NOT NULL CHECK(unit_price>=0));
GRANT SELECT ON public.sale_items TO authenticated; GRANT ALL ON public.sale_items TO service_role;
ALTER TABLE public.sale_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admin sale items read" ON public.sale_items FOR SELECT TO authenticated USING(public.has_role(auth.uid(),'admin'));
CREATE TABLE public.cash_entries (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), kind text NOT NULL CHECK(kind IN ('income','expense')), amount numeric(12,2) NOT NULL CHECK(amount>0), description text NOT NULL CHECK(length(trim(description))>0), category text NOT NULL DEFAULT 'Outros', payment text NOT NULL DEFAULT 'pix' CHECK(payment IN ('pix','cash','card','other')), occurred_on date NOT NULL DEFAULT current_date, created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT,INSERT,UPDATE,DELETE ON public.cash_entries TO authenticated; GRANT ALL ON public.cash_entries TO service_role;
ALTER TABLE public.cash_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admin cash entries" ON public.cash_entries FOR ALL TO authenticated USING(public.has_role(auth.uid(),'admin')) WITH CHECK(public.has_role(auth.uid(),'admin'));
CREATE OR REPLACE FUNCTION public.record_sale(p_items jsonb,p_customer text,p_payment text,p_notes text,p_sold_at timestamptz,p_request_id uuid) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE sid uuid; item jsonb; inv public.inventory; prod public.products; qty integer; price numeric; sum_total numeric:=0;
BEGIN
IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Sem permissão'; END IF;
IF jsonb_typeof(p_items)<>'array' OR jsonb_array_length(p_items)=0 OR jsonb_array_length(p_items)>100 THEN RAISE EXCEPTION 'Selecione os itens'; END IF;
PERFORM pg_advisory_xact_lock(hashtextextended(p_request_id::text,0));
IF EXISTS(SELECT 1 FROM public.sales WHERE id=p_request_id) THEN RETURN p_request_id; END IF;
INSERT INTO public.sales(id,customer,payment,total,notes,sold_at,created_by) VALUES(p_request_id,coalesce(p_customer,''),p_payment,0,coalesce(p_notes,''),p_sold_at,auth.uid()) RETURNING id INTO sid;
FOR item IN SELECT value FROM jsonb_array_elements(p_items) ORDER BY value->>'inventory_id' LOOP
SELECT * INTO inv FROM public.inventory WHERE id=(item->>'inventory_id')::uuid FOR UPDATE;
IF NOT FOUND THEN RAISE EXCEPTION 'Cadastre o estoque deste sabor primeiro'; END IF;
qty:=(item->>'quantity')::integer; price:=(item->>'unit_price')::numeric;
IF qty IS NULL OR qty<=0 OR price IS NULL OR price<0 THEN RAISE EXCEPTION 'Quantidade ou preço inválido'; END IF;
IF inv.quantity<qty THEN RAISE EXCEPTION 'Estoque insuficiente para %',inv.flavor; END IF;
SELECT * INTO prod FROM public.products WHERE id=inv.product_id;
IF prod.sold_out THEN RAISE EXCEPTION 'Pod marcado como esgotado'; END IF;
UPDATE public.inventory SET quantity=quantity-qty WHERE id=inv.id;
INSERT INTO public.sale_items(sale_id,product_id,inventory_id,product_name,flavor,quantity,unit_price) VALUES(sid,prod.id,inv.id,prod.name,inv.flavor,qty,price);
sum_total:=sum_total+round(price,2)*qty;
END LOOP;
UPDATE public.sales SET total=sum_total WHERE id=sid; RETURN sid;
END $$;
REVOKE ALL ON FUNCTION public.record_sale(jsonb,text,text,text,timestamptz,uuid) FROM PUBLIC,anon; GRANT EXECUTE ON FUNCTION public.record_sale(jsonb,text,text,text,timestamptz,uuid) TO authenticated;
CREATE OR REPLACE FUNCTION public.cancel_sale(p_sale_id uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE s public.sales; item public.sale_items;
BEGIN
IF NOT public.has_role(auth.uid(),'admin') THEN RAISE EXCEPTION 'Sem permissão'; END IF;
SELECT * INTO s FROM public.sales WHERE id=p_sale_id FOR UPDATE;
IF NOT FOUND THEN RAISE EXCEPTION 'Venda não encontrada'; END IF;
IF s.status='cancelled' THEN RETURN; END IF;
FOR item IN SELECT * FROM public.sale_items WHERE sale_id=p_sale_id ORDER BY inventory_id LOOP
UPDATE public.inventory SET quantity=quantity+item.quantity WHERE id=item.inventory_id;
END LOOP;
UPDATE public.sales SET status='cancelled' WHERE id=p_sale_id;
END $$;
REVOKE ALL ON FUNCTION public.cancel_sale(uuid) FROM PUBLIC,anon; GRANT EXECUTE ON FUNCTION public.cancel_sale(uuid) TO authenticated;
CREATE INDEX sales_sold_at_idx ON public.sales(sold_at); CREATE INDEX sale_items_sale_idx ON public.sale_items(sale_id); CREATE INDEX cash_entries_date_idx ON public.cash_entries(occurred_on);