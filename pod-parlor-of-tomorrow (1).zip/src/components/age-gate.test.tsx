import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { AgeGate } from "./age-gate";

beforeEach(() => sessionStorage.clear());
afterEach(cleanup);
describe("age confirmation", () => {
  it("blocks store access until the visitor confirms they are at least 18", () => {
    render(
      <AgeGate>
        <div data-testid="store" />
      </AgeGate>,
    );
    expect(screen.queryByTestId("store")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "Sim, tenho 18 anos ou mais" }));
    expect(screen.queryByTestId("store")).not.toBeNull();
  });
  it("keeps the store inaccessible when the visitor is under 18", () => {
    render(
      <AgeGate>
        <div data-testid="store" />
      </AgeGate>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Não tenho 18 anos" }));
    expect(screen.queryByTestId("store")).toBeNull();
    expect(sessionStorage.getItem("crazypods-age-confirmed")).toBeNull();
  });
  it("remembers confirmation during navigation in the same browser session", () => {
    const view = render(
      <AgeGate>
        <div data-testid="store" />
      </AgeGate>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Sim, tenho 18 anos ou mais" }));
    view.unmount();
    render(
      <AgeGate>
        <div data-testid="store" />
      </AgeGate>,
    );
    expect(screen.queryByTestId("store")).not.toBeNull();
  });
});
