import { useEffect, useMemo, useState } from "react";
import { Search, SlidersHorizontal, X, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { productsQuery } from "@/lib/products";
import { brandCats, extraCats, match, ProductGrid, type Cat } from "@/components/shop";
import { Button } from "@/components/ui/button";

export function CatalogBrowser({
  initialQuery = "",
  category = "todos",
}: {
  initialQuery?: string;
  category?: Cat | "todos";
}) {
  const { data: catalog = [], isPending, isError, refetch } = useQuery(productsQuery);
  const [query, setQuery] = useState(initialQuery);
  const [brand, setBrand] = useState<Cat | "todos">("todos");
  const [style, setStyle] = useState<Cat | "todos">("todos");
  const [sort, setSort] = useState("padrao");
  useEffect(() => setQuery(initialQuery), [initialQuery]);
  useEffect(() => {
    setBrand("todos");
    setStyle("todos");
    setQuery(initialQuery);
  }, [category]);
  const list = useMemo(
    () =>
      catalog
        .map((p, i) => ({ p, i }))
        .filter(
          ({ p }) =>
            match(p, category) &&
            match(p, brand) &&
            match(p, style) &&
            `${p.name} ${p.brand} ${p.flavors.join(" ")}`
              .toLocaleLowerCase("pt-BR")
              .includes(query.trim().toLocaleLowerCase("pt-BR")),
        )
        .sort(
          (a, b) =>
            Number(a.p.soldout) - Number(b.p.soldout) ||
            (sort === "menor"
              ? a.p.price - b.p.price
              : sort === "maior"
                ? b.p.price - a.p.price
                : sort === "puffs"
                  ? b.p.puffs - a.p.puffs
                  : a.p.sort - b.p.sort),
        ),
    [catalog, category, brand, style, query, sort],
  );
  const reset = () => {
    setQuery("");
    setBrand("todos");
    setStyle("todos");
    setSort("padrao");
  };
  return (
    <div className="mt-8">
      <div className="flex flex-col gap-3 md:flex-row">
        <div className="flex flex-1 items-center gap-3 rounded-md border border-input bg-card px-4">
          <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
          <input
            aria-label="Filtrar pods por modelo ou sabor"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Qual modelo ou sabor você procura?"
            className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none"
          />
          {query && (
            <Button
              variant="ghost"
              size="icon"
              aria-label="Limpar busca"
              onClick={() => setQuery("")}
            >
              <X />
            </Button>
          )}
        </div>
        <label className="flex items-center gap-2 rounded-md border border-input bg-card px-4 py-3 text-sm">
          <SlidersHorizontal className="h-4 w-4" />
          <span className="sr-only">Ordenar pods</span>
          <select
            aria-label="Ordenar pods"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="min-w-0 bg-card outline-none"
          >
            <option value="padrao">Destaques primeiro</option>
            <option value="menor">Menor preço</option>
            <option value="maior">Maior preço</option>
            <option value="puffs">Mais puffs</option>
          </select>
        </label>
      </div>
      <div className="my-5 space-y-3 border-b border-border pb-5">
        {category === "todos" && (
          <div className="flex items-start gap-3">
            <span className="w-14 shrink-0 py-2 text-xs font-bold text-muted-foreground">
              MARCA
            </span>
            <div className="flex flex-wrap gap-2">
              {[{ id: "todos" as const, label: "Todas" }, ...brandCats].map((c) => (
                <Button
                  size="sm"
                  variant={brand === c.id ? "default" : "secondary"}
                  aria-pressed={brand === c.id}
                  key={c.id}
                  onClick={() => setBrand(c.id)}
                >
                  {c.label}
                </Button>
              ))}
            </div>
          </div>
        )}
        <div className="flex items-start gap-3">
          <span className="w-14 shrink-0 py-2 text-xs font-bold text-muted-foreground">TIPO</span>
          <div className="flex flex-wrap gap-2">
            {[
              { id: "todos" as const, label: "Todos" },
              ...extraCats.filter((c) => c.id !== category),
            ].map((c) => (
              <Button
                size="sm"
                variant={style === c.id ? "default" : "secondary"}
                aria-pressed={style === c.id}
                key={c.id}
                onClick={() => setStyle(c.id)}
                className="h-auto min-h-8 whitespace-normal text-left"
              >
                {c.label}
              </Button>
            ))}
          </div>
        </div>
      </div>
      <div className="mb-5 flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {isPending ? "Carregando pods…" : `${list.length} modelos encontrados`}
        </p>
        {(query || brand !== "todos" || style !== "todos") && (
          <Button variant="ghost" size="sm" onClick={reset}>
            <X />
            Limpar filtros
          </Button>
        )}
      </div>
      {isPending ? (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {Array.from({ length: 4 }, (_, i) => (
            <div key={i} className="h-80 animate-pulse rounded-lg bg-secondary" />
          ))}
        </div>
      ) : isError ? (
        <div className="py-12 text-center">
          <p>Não foi possível carregar os pods.</p>
          <Button className="mt-4" onClick={() => refetch()}>
            Tentar novamente
          </Button>
        </div>
      ) : (
        <>
          <ProductGrid list={list} />
          {list.length === 0 && (
            <div className="flex justify-center">
              <Button variant="secondary" onClick={reset}>
                Limpar filtros
              </Button>
            </div>
          )}
        </>
      )}
      {category !== "todos" && (
        <div className="mt-10 text-center">
          <Button variant="outline" asChild>
            <Link to="/pods">
              Ver catálogo completo
              <ArrowRight />
            </Link>
          </Button>
        </div>
      )}
    </div>
  );
}
