import { render, screen, cleanup } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

const { capture } = vi.hoisted(() => ({ capture: vi.fn() }));
vi.mock("@tanstack/react-query", () => ({
  useQuery: () => ({
    data: [
      {
        id: "ignite",
        name: "Ignite",
        brand: "Ignite",
        flavors: ["Menta"],
        category: "ignite",
        price: 90,
        puffs: 15000,
        soldout: false,
        sort: 1,
      },
      {
        id: "fume",
        name: "Fume",
        brand: "Fume",
        flavors: ["Manga"],
        category: "outras",
        price: 50,
        puffs: 5000,
        soldout: false,
        sort: 2,
      },
    ],
    isPending: false,
    isError: false,
  }),
}));
vi.mock("@/lib/products", () => ({ productsQuery: {} }));
vi.mock("@/components/shop", () => ({
  brandCats: [],
  extraCats: [],
  match: () => true,
  ProductGrid: ({ list }: { list: { p: { id: string } }[] }) => {
    capture(list.map(({ p }) => p.id));
    return null;
  },
}));
import { CatalogBrowser } from "./catalog-browser";
afterEach(cleanup);
describe("Catalog search navigation", () => {
  it("updates results when the header sends a new search on the same page", () => {
    const { rerender } = render(<CatalogBrowser initialQuery="Fume" />);
    expect(capture).toHaveBeenLastCalledWith(["fume"]);
    rerender(<CatalogBrowser initialQuery="Ignite" />);
    expect(capture).toHaveBeenLastCalledWith(["ignite"]);
    expect(screen.getByRole("textbox")).toHaveValue("Ignite");
  });
});
