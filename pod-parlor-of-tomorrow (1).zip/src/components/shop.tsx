import logo from "@/assets/crazy-pods-logo.png.asset.json";
import { AgeGate } from "@/components/age-gate";
import { photoStyle } from "@/lib/photo-layout";
import { Link, useNavigate } from "@tanstack/react-router";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import {
  ShoppingBag,
  Search,
  Zap,
  Truck,
  CreditCard,
  Star,
  Heart,
  Sparkles,
  Battery,
  Wind,
  Flame,
  X,
  Minus,
  Plus,
  Trash2,
  House,
  Grid2X2,
} from "lucide-react";
import { toast } from "sonner";
import {
  type CartItem,
  addToCart,
  setQty as setItemQty,
  cartKey,
  cartTotal,
  cartCount,
  cartMessage,
} from "@/lib/cart";
import type { Product } from "@/lib/products";
import { useQuery } from "@tanstack/react-query";
import { settingsQuery, DEFAULT_SETTINGS, waBase } from "@/lib/settings";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { ImageOff, ArrowUpRight } from "lucide-react";

export type Cat =
  | "lancamentos"
  | "ignite"
  | "elfbar"
  | "lostmary"
  | "oxbar"
  | "waka"
  | "outras"
  | "ate15"
  | "15a30"
  | "mais30"
  | "bateria";
export const match = (p: Product, c: Cat | "todos") => {
  switch (c) {
    case "todos":
      return true;
    case "lancamentos":
      return p.launch;
    case "ate15":
      return p.puffs < 15000;
    case "15a30":
      return p.puffs >= 15000 && p.puffs <= 30000;
    case "mais30":
      return p.puffs > 30000;
    case "bateria":
      return p.rechargeable;
    default:
      return p.category === c;
  }
};
export const brandCats: { id: Cat; label: string; img: string; logo?: string }[] = [
  {
    logo: "/brands/ignite.png",
    id: "ignite",
    label: "Ignite",
    img: "/pods/cut/ignite-v155-ultra.png",
  },
  {
    logo: "/brands/elfbar.png",
    id: "elfbar",
    label: "Elfbar",
    img: "/pods/cut/elfbar-40-000-king.png",
  },
  {
    logo: "/brands/lostmary.png",
    id: "lostmary",
    label: "Lost Mary",
    img: "/pods/cut/lost-mary-15-000.png",
  },
  { logo: "/brands/oxbar.png", id: "oxbar", label: "Oxbar", img: "/pods/cut/oxbar-30-000.png" },
  { logo: "/brands/waka.png", id: "waka", label: "Waka", img: "/pods/cut/waka-50-000.png" },
  { id: "outras", label: "Outras marcas", img: "/pods/cut/dinner-60-000.png" },
];
export const extraCats: { id: Cat; label: string; icon: typeof Zap; desc: string }[] = [
  {
    id: "lancamentos",
    label: "Lançamentos",
    icon: Sparkles,
    desc: "As novidades que acabaram de chegar",
  },
  {
    id: "ate15",
    label: "Até 15k puffs",
    icon: Wind,
    desc: "Compactos e práticos para o dia a dia",
  },
  {
    id: "15a30",
    label: "15k a 30k puffs",
    icon: Flame,
    desc: "O equilíbrio perfeito entre duração e preço",
  },
  { id: "mais30", label: "+30k puffs", icon: Zap, desc: "Os gigantes que duram semanas" },
  {
    id: "bateria",
    label: "Com bateria / cartucho",
    icon: Battery,
    desc: "Recarregáveis e com refil",
  },
];
export const allCats = [
  ...brandCats.map((c) => ({ id: c.id, label: c.label })),
  ...extraCats.map((c) => ({ id: c.id, label: c.label })),
];
export const catLabel = (id: string) => allCats.find((c) => c.id === id)?.label;
export const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.61-.92-2.21-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.08c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.08 1.76-.72 2.01-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35zM12.05 21.5h-.01a9.4 9.4 0 0 1-4.8-1.31l-.34-.2-3.57.93.95-3.48-.22-.36a9.4 9.4 0 0 1-1.45-5.02c0-5.2 4.24-9.43 9.45-9.43 2.52 0 4.89.98 6.67 2.77a9.37 9.37 0 0 1 2.76 6.67c0 5.2-4.24 9.43-9.44 9.43zm8.03-17.46A11.28 11.28 0 0 0 12.05.72C5.8.72.7 5.8.7 12.06c0 2 .52 3.95 1.52 5.67L.6 23.6l6-1.57a11.3 11.3 0 0 0 5.43 1.38h.01c6.26 0 11.35-5.09 11.35-11.34 0-3.03-1.18-5.88-3.32-8.02z" />
    </svg>
  );
}

export function useSettings() {
  const { data } = useQuery(settingsQuery);
  const s = data ?? DEFAULT_SETTINGS;
  return { s, WA_NUM: waBase(s), WA: waBase(s) + encodeURIComponent(s.whatsappMessage) };
}
const waOrder = (WA_NUM: string, p: Product, flavor?: string) =>
  WA_NUM +
  encodeURIComponent(
    `Olá! Vim pelo site da Crazy Pods e quero pedir: ${p.name}${flavor ? ` — sabor ${flavor}` : ""} (${brl(p.price)}).`,
  );

export function PodImage({ p, className }: { p: Product; i: number; className?: string }) {
  const [err, setErr] = useState(false);
  useEffect(() => setErr(false), [p.image]);
  if (!p.image || err)
    return (
      <div
        className={`${className ?? ""} flex flex-col items-center justify-center gap-2 text-muted-foreground`}
      >
        <ImageOff className="h-8 w-8" />
        <span className="text-xs">Foto indisponível</span>
      </div>
    );
  return (
    <img
      src={p.image}
      onError={() => setErr(true)}
      alt={p.name}
      loading="lazy"
      width={400}
      height={400}
      className={`${className ?? ""} pod-fly`}
      style={photoStyle(p)}
    />
  );
}

export function useReveal(dep?: unknown) {
  useEffect(() => {
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
      { threshold: 0.15 },
    );
    document.querySelectorAll(".reveal:not(.in)").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [dep]);
}

const ShopCtx = createContext<{ openPod: (p: Product, i: number) => void }>({ openPod: () => {} });
export const useShop = () => useContext(ShopCtx);

const NAV = [
  { to: "/", label: "Início", icon: House },
  { to: "/pods", label: "Todos os pods", icon: Grid2X2 },
  { to: "/categoria/$cat", params: { cat: "lancamentos" }, label: "Lançamentos", icon: Sparkles },
] as const;

export function ShopShell({ children }: { children: ReactNode }) {
  return (
    <AgeGate>
      <ShopContent>{children}</ShopContent>
    </AgeGate>
  );
}

function ShopContent({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const { s: settings, WA, WA_NUM } = useSettings();
  const [items, setItems] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [open, setOpen] = useState<{ p: Product; i: number } | null>(null);
  const [flavor, setFlavor] = useState<string | undefined>();
  const [qty, setQty] = useState(1);
  const [bump, setBump] = useState(false);
  const [q, setQ] = useState("");
  useEffect(() => {
    try {
      const v = localStorage.getItem("crazypods-cart");
      if (v) setItems(JSON.parse(v));
    } catch {
      /* ignore */
    }
  }, []);
  const saveItems = (fn: (c: CartItem[]) => CartItem[]) =>
    setItems((c) => {
      const n = fn(c);
      localStorage.setItem("crazypods-cart", JSON.stringify(n));
      return n;
    });
  const cart = cartCount(items);
  const openPod = (p: Product, i: number) => {
    setOpen({ p, i });
    setFlavor(undefined);
    setQty(1);
  };
  const add = () => {
    if (!open) return;
    const p = open.p;
    if (p.flavors.length && !flavor) {
      toast.error("Escolha um sabor primeiro.");
      return;
    }
    saveItems((c) =>
      addToCart(c, { id: p.id, name: p.name, flavor: flavor ?? null, price: p.price, qty }),
    );
    toast.success(`${qty}x ${p.name}${flavor ? ` (${flavor})` : ""} adicionado ao carrinho`);
    setOpen(null);
    setQty(1);
    setBump(true);
    setTimeout(() => setBump(false), 400);
  };
  const search = (e: React.FormEvent) => {
    e.preventDefault();
    navigate({ to: "/pods", search: { q: q || undefined } });
  };

  return (
    <ShopCtx.Provider value={{ openPod }}>
      <div className="min-h-screen overflow-x-hidden">
        <div className="border-b border-border bg-muted/50 text-xs">
          <div className="flex overflow-hidden whitespace-nowrap py-2">
            <div className="flex animate-marquee gap-12 pr-12">
              {Array.from({ length: 2 }).flatMap((_, k) =>
                settings.marquee
                  .map((t, j) => [[Truck, Zap, Star, CreditCard][j % 4], t])
                  .map(([I, t], j) => {
                    const Ic = I as typeof Zap;
                    return (
                      <span
                        key={`${k}${j}`}
                        className="flex items-center gap-2 text-muted-foreground"
                      >
                        <Ic className="h-3.5 w-3.5 text-primary-glow" />
                        {t as string}
                      </span>
                    );
                  }),
              )}
            </div>
          </div>
        </div>

        <header className="store-header sticky top-0 z-40 border-b border-border">
          <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-3 md:flex">
            <Link
              to="/"
              aria-label="Crazy Pods — Início"
              className="flex shrink-0 items-center gap-3"
            >
              <img
                src={logo.url}
                alt="Crazy Pods"
                width={80}
                height={80}
                className="h-20 w-20 rounded-md border border-border object-cover"
              />
              <span className="hidden font-display text-sm font-bold xl:block">CRAZY PODS</span>
            </Link>
            <nav aria-label="Navegação principal" className="hidden items-center gap-1 md:flex">
              {NAV.map((n) => (
                <Link
                  key={n.label}
                  {...(n as { to: "/" })}
                  activeOptions={{ exact: true }}
                  className="shop-nav-link"
                >
                  <n.icon className="h-4 w-4 shrink-0" />
                  {n.label}
                </Link>
              ))}
            </nav>
            <form
              onSubmit={search}
              role="search"
              className="ml-auto hidden items-center gap-2 rounded-md bg-secondary px-4 py-2.5 lg:flex"
            >
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                aria-label="Buscar no catálogo"
                placeholder="Buscar pods, sabores..."
                className="w-48 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
            </form>
            <Button
              variant="ghost"
              aria-label="Carrinho"
              onClick={() => setCartOpen(true)}
              className={`relative ml-auto rounded-full p-2 transition hover:bg-secondary lg:ml-0 ${bump ? "scale-125" : ""}`}
            >
              <ShoppingBag className="h-5 w-5" />
              {cart > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 w-5 place-items-center rounded-full bg-gradient-primary text-[10px] font-bold text-primary-foreground">
                  {cart}
                </span>
              )}
            </Button>
          </div>
          <nav
            aria-label="Navegação principal"
            className="mx-4 grid grid-cols-3 border-t border-border md:hidden"
          >
            {NAV.map((n) => (
              <Link
                key={n.label}
                {...(n as { to: "/" })}
                activeOptions={{ exact: true }}
                className="shop-nav-link"
              >
                <n.icon className="h-4 w-4 shrink-0" />
                {n.label}
              </Link>
            ))}
          </nav>
          <form
            onSubmit={search}
            role="search"
            className="mx-5 mb-3 flex items-center gap-2 rounded-md border border-border bg-secondary px-3 lg:hidden"
          >
            <Search className="h-4 w-4 text-muted-foreground" />
            <input
              aria-label="Buscar no catálogo"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar modelo ou sabor"
              className="min-w-0 flex-1 bg-transparent py-2.5 text-sm outline-none"
            />
            <Button type="submit" variant="ghost" size="icon" aria-label="Pesquisar">
              <ArrowUpRight />
            </Button>
          </form>
        </header>

        <main>{children}</main>

        <footer className="chrome-band mt-12 px-5 py-10 text-center text-sm text-muted-foreground">
          <img
            src={logo.url}
            alt="Crazy Pods"
            width={64}
            height={64}
            className="mx-auto h-16 w-16 rounded-xl object-cover"
          />
          <div className="mx-auto mt-4 flex max-w-xl flex-wrap justify-center gap-x-4 gap-y-2">
            <Link to="/pods" className="hover:text-foreground">
              Todos os pods
            </Link>
            {brandCats.map((c) => (
              <Link
                key={c.id}
                to="/categoria/$cat"
                params={{ cat: c.id }}
                className="hover:text-foreground"
              >
                {c.label}
              </Link>
            ))}
          </div>
          <p className="mt-4">Venda proibida para menores de 18 anos.</p>
        </footer>

        <a
          href={WA}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="WhatsApp"
          className="fixed bottom-6 right-6 z-50 grid h-14 w-14 place-items-center rounded-full bg-whatsapp text-primary-foreground shadow-glow transition hover:scale-110"
        >
          <WhatsAppIcon className="h-7 w-7" />
        </a>

        <Dialog
          open={!!open}
          onOpenChange={(value) => {
            if (!value) setOpen(null);
          }}
        >
          {open && (
            <DialogContent
              aria-describedby={undefined}
              className="max-h-[90dvh] w-[calc(100%-2rem)] max-w-3xl gap-0 overflow-y-auto rounded-lg bg-card p-0 md:grid-cols-2"
            >
              <div className="bg-product-stage relative grid min-h-64 place-items-center p-8">
                <PodImage
                  p={open.p}
                  i={open.i}
                  className="relative h-72 w-full animate-float object-contain"
                />
              </div>
              <div className="min-w-0 p-6 md:p-8">
                <p className="text-xs font-bold tracking-widest text-primary-glow">
                  {open.p.brand.toUpperCase()}
                  {open.p.launch ? " · LANÇAMENTO 🚀" : ""}
                </p>
                <DialogTitle className="product-name mt-2 font-display text-2xl font-black">
                  {open.p.name}
                </DialogTitle>
                <p className="mt-2 font-display text-3xl font-bold text-gradient">
                  {brl(open.p.price)}
                </p>
                {open.p.note && (
                  <p className="mt-3 rounded-xl bg-secondary px-3 py-2 text-sm text-muted-foreground">
                    {open.p.note}
                  </p>
                )}
                <p className="mt-5 text-sm font-bold">
                  {open.p.flavors.length
                    ? "Escolha o sabor"
                    : open.p.soldout
                      ? "Esgotado no momento"
                      : "Sem opções de sabor"}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {open.p.flavors.map((f) => (
                    <Button
                      variant="secondary"
                      aria-pressed={flavor === f}
                      key={f}
                      onClick={() => setFlavor(f)}
                      className={`h-auto max-w-full whitespace-normal break-words rounded-full border px-3 py-2 text-xs font-semibold transition ${flavor === f ? "border-primary bg-commerce-hover text-commerce-foreground" : "border-border bg-secondary hover:border-primary"}`}
                    >
                      {f}
                    </Button>
                  ))}
                </div>
                {open.p.soldout ? (
                  <a
                    href={waOrder(WA_NUM, open.p, flavor)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-whatsapp px-6 py-4 font-bold text-primary-foreground"
                  >
                    <WhatsAppIcon className="h-5 w-5" />
                    Avise-me quando chegar
                  </a>
                ) : (
                  <div className="mt-6 flex flex-wrap items-center gap-3">
                    <div className="flex shrink-0 items-center rounded-full bg-secondary">
                      <Button
                        variant="ghost"
                        aria-label="Diminuir"
                        onClick={() => setQty((x) => Math.max(1, x - 1))}
                        className="p-3"
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="w-6 text-center font-bold">{qty}</span>
                      <Button
                        variant="ghost"
                        aria-label="Aumentar"
                        onClick={() => setQty((x) => x + 1)}
                        className="p-3"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button
                      onClick={add}
                      variant="commerce"
                      className="h-auto min-h-12 min-w-0 flex-1 basis-48 whitespace-normal rounded-full px-4 py-3 font-bold"
                    >
                      <ShoppingBag className="h-5 w-5" />
                      <span>
                        Adicionar ao carrinho{" "}
                        <span className="block text-xs font-medium text-muted-foreground">
                          {brl(open.p.price * qty)}
                        </span>
                      </span>
                    </Button>
                  </div>
                )}
              </div>
            </DialogContent>
          )}
        </Dialog>

        <Sheet open={cartOpen} onOpenChange={setCartOpen}>
          <SheetContent
            aria-describedby={undefined}
            className="flex w-full flex-col bg-card p-0 sm:max-w-md"
          >
            <div className="flex items-center justify-between border-b border-border p-5">
              <SheetTitle className="font-display text-xl font-bold">Seu carrinho</SheetTitle>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto p-5">
              {items.length === 0 && (
                <p className="py-16 text-center text-muted-foreground">
                  Seu carrinho está vazio.
                  <br />
                  Toque em um pod para escolher o sabor.
                </p>
              )}
              {items.map((it) => {
                const k = cartKey(it);
                return (
                  <div key={k} className="glass rounded-lg p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-bold">{it.name}</p>
                        {it.flavor && (
                          <p className="text-sm text-muted-foreground">Sabor: {it.flavor}</p>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        aria-label="Remover"
                        onClick={() => saveItems((c) => setItemQty(c, k, 0))}
                        className="text-muted-foreground hover:text-foreground"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center rounded-full bg-secondary">
                        <Button
                          variant="ghost"
                          aria-label="Diminuir"
                          onClick={() => saveItems((c) => setItemQty(c, k, it.qty - 1))}
                          className="p-2"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </Button>
                        <span className="w-6 text-center text-sm font-bold">{it.qty}</span>
                        <Button
                          variant="ghost"
                          aria-label="Aumentar"
                          onClick={() => saveItems((c) => setItemQty(c, k, it.qty + 1))}
                          className="p-2"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                      <p className="font-display font-bold text-gradient">
                        {brl(it.price * it.qty)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
            {items.length > 0 && (
              <div className="border-t border-border p-5">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">
                    Total ({cart} {cart === 1 ? "item" : "itens"})
                  </span>
                  <span className="font-display text-2xl font-bold text-gradient">
                    {brl(cartTotal(items))}
                  </span>
                </div>
                <a
                  href={WA_NUM + encodeURIComponent(cartMessage(items))}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-whatsapp px-6 py-4 font-bold text-primary-foreground transition hover:scale-[1.02]"
                >
                  <WhatsAppIcon className="h-5 w-5" />
                  Enviar pedido no WhatsApp
                </a>
                <Button
                  variant="ghost"
                  onClick={() => saveItems(() => [])}
                  className="mt-3 w-full text-center text-sm text-muted-foreground hover:text-foreground"
                >
                  Esvaziar carrinho
                </Button>
              </div>
            )}
          </SheetContent>
        </Sheet>
      </div>
    </ShopCtx.Provider>
  );
}

export function ProductGrid({ list }: { list: { p: Product; i: number }[] }) {
  const { openPod } = useShop();
  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-5 lg:grid-cols-4">
      {list.map(({ p, i }) => (
        <article
          key={p.slug}
          className="group flex min-w-0 flex-col overflow-hidden rounded-lg border border-border bg-card transition duration-300 hover:-translate-y-1 hover:border-primary"
        >
          <Button
            variant="ghost"
            aria-label={`Ver sabores de ${p.name}`}
            onClick={() => openPod(p, i)}
            className="bg-product-stage relative h-52 w-full rounded-none p-5 hover:bg-transparent sm:h-64"
          >
            <span
              className={`absolute left-3 top-3 z-10 rounded-sm px-2 py-1 text-[10px] font-bold ${p.soldout ? "bg-destructive text-destructive-foreground" : p.launch ? "bg-primary text-primary-foreground" : "bg-background text-foreground"}`}
            >
              {p.soldout ? "Esgotado" : p.launch ? "Lançamento" : p.brand}
            </span>
            <PodImage
              p={p}
              i={i}
              className="mt-3 h-40 w-full object-contain transition duration-500 group-hover:-translate-y-2 group-hover:scale-105 sm:h-48"
            />
          </Button>
          <div className="flex flex-1 flex-col p-3 sm:p-4">
            <h3 className="product-name font-display text-sm font-bold leading-snug">{p.name}</h3>
            {p.puffs > 0 && (
              <p className="mt-2 flex items-center gap-1 text-xs text-accent">
                <Wind className="h-3 w-3" />
                {p.puffs.toLocaleString("pt-BR")} puffs
              </p>
            )}
            <p className="mt-1 text-xs text-muted-foreground">
              {p.flavors.length} sabores disponíveis
            </p>
            <div className="mt-auto flex flex-wrap items-center justify-between gap-x-2 gap-y-3 pt-4">
              <p className="font-display text-base font-bold sm:text-lg">{brl(p.price)}</p>
              <Button
                onClick={() => openPod(p, i)}
                variant="commerce"
                className="h-auto min-h-9 max-w-full shrink-0 whitespace-normal rounded-full px-3 py-2 text-xs font-bold"
              >
                {p.soldout ? "Consultar" : "Ver sabores"}
              </Button>
            </div>
          </div>
        </article>
      ))}
      {list.length === 0 && (
        <p className="col-span-full py-12 text-center text-muted-foreground">
          Nenhum pod encontrado.
        </p>
      )}
    </div>
  );
}
