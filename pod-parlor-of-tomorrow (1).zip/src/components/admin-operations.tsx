import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Plus,
  Trash2,
  Download,
  Package,
  ArrowDownLeft,
  ArrowUpRight,
  Wallet,
  ReceiptText,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { productsQuery } from "@/lib/products";
import { supabase } from "@/integrations/supabase/client";
import {
  operationsQuery,
  financialSummary,
  payments,
  csvCell,
  type Payment,
} from "@/lib/operations";

const brl = (n: number) =>
  Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const today = () => new Date().toLocaleDateString("en-CA", { timeZone: "America/Sao_Paulo" });
const dateOf = (v: string) =>
  new Date(v).toLocaleDateString("en-CA", { timeZone: "America/Sao_Paulo" });
const field =
  "w-full min-w-0 rounded-md border border-input bg-secondary px-3 py-2.5 text-sm outline-none focus:border-primary";
type Line = { inventory_id: string; quantity: number; unit_price: number };
export type OperationsView = "overview" | "stock" | "sales" | "finance";

export function AdminOperations({ view }: { view: OperationsView }) {
  const qc = useQueryClient();
  const { data, isPending, isError, refetch } = useQuery(operationsQuery);
  const { data: products = [] } = useQuery(productsQuery);
  const [start, setStart] = useState(() => today().slice(0, 7) + "-01");
  const [end, setEnd] = useState(today);
  const [search, setSearch] = useState("");
  const [modal, setModal] = useState<"sale" | "stock" | "entry" | null>(null);
  const [busy, setBusy] = useState(false);
  const [productId, setProductId] = useState("");
  const [flavor, setFlavor] = useState("");
  const [quantity, setQuantity] = useState("0");
  const [lowStock, setLowStock] = useState("3");
  const [lines, setLines] = useState<Line[]>([]);
  const [customer, setCustomer] = useState("");
  const [payment, setPayment] = useState<Payment>("pix");
  const [date, setDate] = useState(today);
  const [notes, setNotes] = useState("");
  const [requestId, setRequestId] = useState("");
  const [kind, setKind] = useState("expense");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Outros");
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["operations"] });
  };
  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
      refresh();
      setModal(null);
      toast.success("Registro salvo.");
    } catch (e) {
      toast.error(
        e && typeof e === "object" && "message" in e
          ? String(e.message)
          : "Não foi possível salvar.",
      );
    } finally {
      setBusy(false);
    }
  };
  const inv = data?.inventory ?? [];
  const sales = (data?.sales ?? []).filter(
    (s) => dateOf(s.sold_at) >= start && dateOf(s.sold_at) <= end,
  );
  const entries = (data?.entries ?? []).filter(
    (e) => e.occurred_on >= start && e.occurred_on <= end,
  );
  const summary = financialSummary(sales, entries);
  const selectedProduct = products.find((p) => p.id === productId);
  const stockRows = products
    .flatMap((p) =>
      (p.flavors.length ? p.flavors : [""]).map((f) => ({
        p,
        f,
        stock: inv.find((i) => i.product_id === p.id && i.flavor === f),
      })),
    )
    .filter(({ p, f }) =>
      `${p.name} ${f}`.toLocaleLowerCase().includes(search.toLocaleLowerCase()),
    );
  const low = inv.filter((i) => i.quantity <= i.low_stock);
  const openSale = () => {
    setLines([{ inventory_id: "", quantity: 1, unit_price: 0 }]);
    setCustomer("");
    setPayment("pix");
    setNotes("");
    setDate(today());
    setRequestId(crypto.randomUUID());
    setModal("sale");
  };
  const saveSale = () =>
    run(async () => {
      if (
        !lines.length ||
        lines.some(
          (l) =>
            !l.inventory_id ||
            !Number.isInteger(l.quantity) ||
            l.quantity <= 0 ||
            !Number.isFinite(l.unit_price) ||
            l.unit_price < 0,
        )
      )
        throw new Error("Selecione os itens e informe quantidade e preço válidos.");
      if (!date) throw new Error("Informe a data.");
      const { error } = await supabase.rpc("record_sale", {
        p_items: lines,
        p_customer: customer,
        p_payment: payment,
        p_notes: notes,
        p_sold_at: date + "T12:00:00-03:00",
        p_request_id: requestId,
      });
      if (error) throw error;
    });
  const saveStock = () =>
    run(async () => {
      if (
        !selectedProduct ||
        (selectedProduct.flavors.length && !selectedProduct.flavors.includes(flavor))
      )
        throw new Error("Selecione o pod e o sabor.");
      const n = Number(quantity),
        l = Number(lowStock);
      if (!Number.isInteger(n) || n < 0 || !Number.isInteger(l) || l < 0)
        throw new Error("Use quantidades inteiras a partir de zero.");
      const { error } = await supabase
        .from("inventory")
        .upsert(
          { product_id: productId, flavor, quantity: n, low_stock: l },
          { onConflict: "product_id,flavor" },
        );
      if (error) throw error;
    });
  const saveEntry = () =>
    run(async () => {
      const n = Number(amount.replace(",", "."));
      if (!description.trim() || !date || !Number.isFinite(n) || n <= 0)
        throw new Error("Informe descrição, data e valor maior que zero.");
      const { error } = await supabase
        .from("cash_entries")
        .insert({
          kind,
          amount: n,
          description: description.trim(),
          category,
          payment,
          occurred_on: date,
        });
      if (error) throw error;
    });
  const exportCsv = () => {
    const rows = [
      ["Data", "Tipo", "Descrição", "Pagamento", "Valor"],
      ...sales.map((s) => [
        dateOf(s.sold_at),
        s.status === "cancelled" ? "Venda cancelada" : "Venda",
        s.customer || "Sem cliente",
        payments[s.payment as Payment],
        s.total,
      ]),
      ...entries.map((e) => [
        e.occurred_on,
        e.kind === "income" ? "Entrada" : "Despesa",
        e.description,
        payments[e.payment as Payment],
        e.amount,
      ]),
    ];
    const url = URL.createObjectURL(
      new Blob(["\ufeff" + rows.map((r) => r.map(csvCell).join(";")).join("\r\n")], {
        type: "text/csv;charset=utf-8",
      }),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = `crazy-pods-${start}-${end}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  if (isPending) return <p className="py-12 text-muted-foreground">Carregando gestão…</p>;
  if (isError)
    return (
      <div className="py-12">
        <p>Não foi possível carregar a gestão.</p>
        <Button onClick={() => refetch()} className="mt-4">
          Tentar novamente
        </Button>
      </div>
    );
  const title = {
    overview: "Visão geral",
    stock: "Estoque",
    sales: "Vendas",
    finance: "Financeiro",
  }[view];
  return (
    <>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-2xl font-bold">{title}</h1>
        <div className="flex flex-wrap gap-2">
          {(view === "overview" || view === "sales") && (
            <Button variant="commerce" onClick={openSale}>
              <Plus />
              Registrar venda
            </Button>
          )}
          {(view === "overview" || view === "finance") && (
            <Button
              variant="secondary"
              onClick={() => {
                setDescription("");
                setAmount("");
                setDate(today());
                setKind("expense");
                setModal("entry");
              }}
            >
              <Plus />
              Entrada / despesa
            </Button>
          )}
        </div>
      </div>
      {view !== "stock" && (
        <div className="mt-6 flex flex-wrap items-end gap-3 border-b border-border pb-5">
          <label className="text-xs">
            De
            <input
              aria-label="Data inicial"
              type="date"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className={`${field} mt-1`}
            />
          </label>
          <label className="text-xs">
            Até
            <input
              aria-label="Data final"
              type="date"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className={`${field} mt-1`}
            />
          </label>
          <Button variant="ghost" onClick={exportCsv}>
            <Download />
            Exportar
          </Button>
        </div>
      )}
      {(view === "overview" || view === "finance") && (
        <div className="my-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            [ArrowDownLeft, "Entradas", summary.income],
            [ArrowUpRight, "Despesas", summary.expenses],
            [Wallet, "Saldo do período", summary.balance],
            [ReceiptText, "Vendas recebidas", summary.salesTotal],
          ].map(([I, label, value]) => {
            const Icon = I as typeof Wallet;
            return (
              <div key={String(label)} className="rounded-lg border border-border bg-card p-4">
                <Icon className="mb-3 h-5 w-5 text-muted-foreground" />
                <p className="text-xs text-muted-foreground">{String(label)}</p>
                <p className="mt-2 break-words text-xl font-bold tabular-nums">
                  {brl(Number(value))}
                </p>
              </div>
            );
          })}
        </div>
      )}
      {view === "overview" && (
        <div className="my-8 grid gap-6 md:grid-cols-2">
          <section>
            <h2 className="mb-3 flex items-center gap-2 font-bold">
              <Package className="h-4 w-4" />
              Estoque em atenção · {low.length}
            </h2>
            {low.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum alerta de estoque cadastrado.</p>
            ) : (
              low.slice(0, 8).map((i) => (
                <div
                  key={i.id}
                  className="flex justify-between gap-3 border-b border-border py-3 text-sm"
                >
                  <span>
                    {products.find((p) => p.id === i.product_id)?.name} · {i.flavor || "Sem sabor"}
                  </span>
                  <strong>{i.quantity} un.</strong>
                </div>
              ))
            )}
            <p className="mt-4 text-sm text-muted-foreground">
              {inv.reduce((n, i) => n + i.quantity, 0)} unidades cadastradas ·{" "}
              {products.filter((p) => !inv.some((i) => i.product_id === p.id)).length} pods sem
              estoque informado
            </p>
          </section>
          <section>
            <h2 className="mb-3 font-bold">Recebimentos por pagamento</h2>
            {Object.entries(payments).map(([id, label]) => (
              <div key={id} className="flex justify-between border-b border-border py-3 text-sm">
                <span>{label}</span>
                <strong>
                  {brl(
                    sales
                      .filter((s) => s.status === "completed" && s.payment === id)
                      .reduce((n, s) => n + Number(s.total), 0) +
                      entries
                        .filter((e) => e.kind === "income" && e.payment === id)
                        .reduce((n, e) => n + Number(e.amount), 0),
                  )}
                </strong>
              </div>
            ))}
          </section>
        </div>
      )}
      {view === "stock" && (
        <>
          <input
            aria-label="Buscar estoque"
            placeholder="Buscar pod ou sabor"
            className={`${field} my-6 max-w-md`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs text-muted-foreground">
                <tr>
                  <th className="py-3">Pod / sabor</th>
                  <th className="p-3">Quantidade</th>
                  <th className="p-3">Situação</th>
                  <th className="p-3">Ajuste</th>
                </tr>
              </thead>
              <tbody>
                {stockRows.map(({ p, f, stock }) => (
                  <tr key={p.id + f} className="border-t border-border">
                    <td className="py-3">
                      <p className="font-semibold">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{f || "Sem sabor"}</p>
                    </td>
                    <td className="p-3 tabular-nums">{stock?.quantity ?? "—"}</td>
                    <td className="p-3 text-xs">
                      {!stock
                        ? "Não informado"
                        : stock.quantity === 0
                          ? "Sem estoque"
                          : stock.quantity <= stock.low_stock
                            ? "Estoque baixo"
                            : "Disponível"}
                    </td>
                    <td className="p-3">
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => {
                          setProductId(p.id);
                          setFlavor(f);
                          setQuantity(String(stock?.quantity ?? 0));
                          setLowStock(String(stock?.low_stock ?? 3));
                          setModal("stock");
                        }}
                      >
                        Ajustar
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!stockRows.length && (
            <p className="py-8 text-muted-foreground">Nenhum pod encontrado.</p>
          )}
        </>
      )}
      {(view === "sales" || view === "overview") && (
        <section className="mt-8">
          <h2 className="mb-4 font-bold">Vendas do período · {sales.length}</h2>
          {!sales.length && (
            <p className="py-8 text-muted-foreground">Nenhuma venda registrada neste período.</p>
          )}
          {sales.map((s) => (
            <article key={s.id} className="border-t border-border py-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-bold">
                    {s.customer || "Cliente não informado"}{" "}
                    <span className="ml-2 text-xs font-normal text-muted-foreground">
                      {s.status === "cancelled" ? "Cancelada" : "Recebida"}
                    </span>
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {new Date(s.sold_at).toLocaleDateString("pt-BR", {
                      timeZone: "America/Sao_Paulo",
                    })}{" "}
                    · {payments[s.payment as Payment]}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <strong>{brl(s.total)}</strong>
                  {s.status !== "cancelled" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={busy}
                      onClick={() => {
                        if (confirm("Cancelar a venda e devolver os itens ao estoque?"))
                          run(async () => {
                            const { error } = await supabase.rpc("cancel_sale", {
                              p_sale_id: s.id,
                            });
                            if (error) throw error;
                          });
                      }}
                    >
                      Cancelar venda
                    </Button>
                  )}
                </div>
              </div>
              <div className="mt-3 text-sm text-muted-foreground">
                {data?.items
                  .filter((i) => i.sale_id === s.id)
                  .map((i) => (
                    <p key={i.id}>
                      {i.quantity}× {i.product_name} {i.flavor && `· ${i.flavor}`} ·{" "}
                      {brl(i.unit_price)} cada
                    </p>
                  ))}
                {s.notes && <p className="mt-2">{s.notes}</p>}
              </div>
            </article>
          ))}
        </section>
      )}
      {view === "finance" && (
        <section>
          <h2 className="my-5 font-bold">Outras entradas e despesas</h2>
          {!entries.length && (
            <p className="py-8 text-muted-foreground">Nenhum lançamento neste período.</p>
          )}
          {entries.map((e) => (
            <div
              key={e.id}
              className="flex items-center justify-between gap-3 border-t border-border py-4"
            >
              <div className="min-w-0">
                <p className="break-words font-semibold">{e.description}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {e.occurred_on.split("-").reverse().join("/")} · {e.category} ·{" "}
                  {payments[e.payment as Payment]}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <span className="text-sm font-bold">
                  {e.kind === "expense" ? "−" : "+"} {brl(e.amount)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={`Excluir ${e.description}`}
                  disabled={busy}
                  onClick={() => {
                    if (confirm("Excluir este lançamento?"))
                      run(async () => {
                        const { error } = await supabase
                          .from("cash_entries")
                          .delete()
                          .eq("id", e.id);
                        if (error) throw error;
                      });
                  }}
                >
                  <Trash2 />
                </Button>
              </div>
            </div>
          ))}
        </section>
      )}
      <Dialog
        open={modal !== null}
        onOpenChange={(v) => {
          if (!v && !busy) setModal(null);
        }}
      >
        <DialogContent
          aria-describedby={undefined}
          className="max-h-[90dvh] w-[calc(100%-2rem)] max-w-2xl overflow-y-auto bg-card"
        >
          <DialogTitle>
            {modal === "sale"
              ? "Registrar venda recebida"
              : modal === "stock"
                ? "Ajustar estoque"
                : "Entrada / despesa"}
          </DialogTitle>
          {modal === "stock" && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                saveStock();
              }}
              className="grid gap-4"
            >
              <p className="font-semibold">
                {selectedProduct?.name} · {flavor || "Sem sabor"}
              </p>
              <label className="text-sm">
                Quantidade atual
                <input
                  aria-label="Quantidade em estoque"
                  type="number"
                  min="0"
                  step="1"
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className={`${field} mt-1`}
                />
              </label>
              <label className="text-sm">
                Alertar quando chegar a
                <input
                  aria-label="Limite de estoque baixo"
                  type="number"
                  min="0"
                  step="1"
                  required
                  value={lowStock}
                  onChange={(e) => setLowStock(e.target.value)}
                  className={`${field} mt-1`}
                />
              </label>
              <Button variant="commerce" type="submit" disabled={busy}>
                Salvar estoque
              </Button>
            </form>
          )}
          {modal === "sale" && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                saveSale();
              }}
              className="grid gap-4"
            >
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="text-sm">
                  Cliente
                  <input
                    aria-label="Cliente"
                    className={`${field} mt-1`}
                    value={customer}
                    onChange={(e) => setCustomer(e.target.value)}
                    maxLength={150}
                  />
                </label>
                <label className="text-sm">
                  Data
                  <input
                    aria-label="Data da venda"
                    type="date"
                    required
                    className={`${field} mt-1`}
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                  />
                </label>
              </div>
              {lines.map((line, index) => (
                <div
                  key={index}
                  className="grid grid-cols-[1fr_1fr_auto] items-end gap-2 border-t border-border pt-3"
                >
                  <label className="col-span-3 text-xs">
                    Pod e sabor
                    <select
                      aria-label={`Item ${index + 1}`}
                      required
                      className={`${field} mt-1`}
                      value={line.inventory_id}
                      onChange={(e) => {
                        const id = e.target.value;
                        const i = inv.find((i) => i.id === id);
                        const price = products.find((p) => p.id === i?.product_id)?.price ?? 0;
                        setLines((ls) =>
                          ls.map((l, j) =>
                            j === index ? { ...l, inventory_id: id, unit_price: price } : l,
                          ),
                        );
                      }}
                    >
                      <option value="">Selecionar pod / sabor</option>
                      {inv
                        .filter(
                          (i) =>
                            i.quantity > 0 && !products.find((p) => p.id === i.product_id)?.soldout,
                        )
                        .map((i) => (
                          <option key={i.id} value={i.id}>
                            {products.find((p) => p.id === i.product_id)?.name} ·{" "}
                            {i.flavor || "Sem sabor"} ({i.quantity} un.)
                          </option>
                        ))}
                    </select>
                  </label>
                  <label className="text-xs">
                    Quantidade
                    <input
                      aria-label={`Quantidade item ${index + 1}`}
                      type="number"
                      required
                      min="1"
                      step="1"
                      value={line.quantity}
                      className={`${field} mt-1`}
                      onChange={(e) =>
                        setLines((ls) =>
                          ls.map((l, j) =>
                            j === index ? { ...l, quantity: Number(e.target.value) } : l,
                          ),
                        )
                      }
                    />
                  </label>
                  <label className="text-xs">
                    Preço unitário
                    <input
                      aria-label={`Preço item ${index + 1}`}
                      type="number"
                      required
                      min="0"
                      step="0.01"
                      value={line.unit_price}
                      className={`${field} mt-1`}
                      onChange={(e) =>
                        setLines((ls) =>
                          ls.map((l, j) =>
                            j === index ? { ...l, unit_price: Number(e.target.value) } : l,
                          ),
                        )
                      }
                    />
                  </label>
                  <Button
                    variant="ghost"
                    size="icon"
                    type="button"
                    aria-label={`Remover item ${index + 1}`}
                    onClick={() => setLines((ls) => ls.filter((_, j) => j !== index))}
                  >
                    <Trash2 />
                  </Button>
                </div>
              ))}
              <Button
                variant="secondary"
                type="button"
                onClick={() =>
                  setLines((ls) => [...ls, { inventory_id: "", quantity: 1, unit_price: 0 }])
                }
              >
                <Plus />
                Adicionar item
              </Button>
              <label className="text-sm">
                Pagamento recebido
                <select
                  aria-label="Pagamento"
                  className={`${field} mt-1`}
                  value={payment}
                  onChange={(e) => setPayment(e.target.value as Payment)}
                >
                  {Object.entries(payments).map(([id, label]) => (
                    <option key={id} value={id}>
                      {label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-sm">
                Observações
                <textarea
                  aria-label="Observações"
                  maxLength={1000}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className={`${field} mt-1`}
                />
              </label>
              <p className="text-xl font-bold">
                Total: {brl(lines.reduce((n, l) => n + l.quantity * l.unit_price, 0))}
              </p>
              <Button variant="commerce" disabled={busy || !lines.length} type="submit">
                {busy ? "Salvando…" : "Confirmar venda recebida"}
              </Button>
            </form>
          )}
          {modal === "entry" && (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                saveEntry();
              }}
              className="grid gap-4"
            >
              <div className="flex gap-2">
                {([
                  ["income", "Entrada"],
                  ["expense", "Despesa"],
                ] as const).map(([id, label]) => (
                  <Button
                    key={id}
                    type="button"
                    variant={kind === id ? "commerce" : "secondary"}
                    aria-pressed={kind === id}
                    onClick={() => setKind(id)}
                  >
                    {label}
                  </Button>
                ))}
              </div>
              <label className="text-sm">
                Descrição
                <input
                  aria-label="Descrição do lançamento"
                  required
                  maxLength={200}
                  className={`${field} mt-1`}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="text-sm">
                  Valor (R$)
                  <input
                    aria-label="Valor do lançamento"
                    inputMode="decimal"
                    required
                    className={`${field} mt-1`}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </label>
                <label className="text-sm">
                  Data
                  <input
                    aria-label="Data do lançamento"
                    type="date"
                    required
                    className={`${field} mt-1`}
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                  />
                </label>
              </div>
              <label className="text-sm">
                Categoria
                <select
                  aria-label="Categoria do lançamento"
                  className={`${field} mt-1`}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  {[
                    "Outros",
                    "Reposição de estoque",
                    "Entrega",
                    "Aluguel",
                    "Marketing",
                    "Retirada",
                    "Aporte",
                  ].map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </label>
              <label className="text-sm">
                Pagamento
                <select
                  aria-label="Pagamento do lançamento"
                  className={`${field} mt-1`}
                  value={payment}
                  onChange={(e) => setPayment(e.target.value as Payment)}
                >
                  {Object.entries(payments).map(([id, label]) => (
                    <option key={id} value={id}>
                      {label}
                    </option>
                  ))}
                </select>
              </label>
              <Button variant="commerce" type="submit" disabled={busy}>
                Salvar lançamento
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
