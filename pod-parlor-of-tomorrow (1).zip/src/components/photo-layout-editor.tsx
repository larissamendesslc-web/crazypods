import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { DEFAULT_PHOTO_LAYOUT, photoStyle, type PhotoLayout } from "@/lib/photo-layout";

export function PhotoLayoutEditor({
  image,
  value,
  onChange,
}: {
  image: string;
  value: PhotoLayout;
  onChange: (value: PhotoLayout) => void;
}) {
  const fields = [
    { key: "imageScale", label: "Tamanho da foto", min: 50, max: 150, fallback: 100 },
    { key: "imageX", label: "Posição horizontal", min: -25, max: 25, fallback: 0 },
    { key: "imageY", label: "Posição vertical", min: -25, max: 25, fallback: 0 },
  ] as const;
  return (
    <section className="mt-5 border-y border-border py-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h3 className="text-sm font-bold">Ajustar foto</h3>
        <Button
          variant="ghost"
          size="icon"
          title="Restaurar tamanho e posição"
          aria-label="Restaurar tamanho e posição"
          onClick={() => onChange(DEFAULT_PHOTO_LAYOUT)}
        >
          <RotateCcw />
        </Button>
      </div>
      <div className="grid gap-6 sm:grid-cols-[180px_1fr]">
        <div
          className="bg-product-stage grid aspect-square place-items-center overflow-hidden rounded-lg border border-border"
          aria-label="Prévia da foto"
        >
          <img
            src={image}
            alt="Prévia do pod"
            className="pod-fly h-36 w-36 object-contain"
            style={photoStyle(value)}
          />
        </div>
        <div className="flex flex-col justify-center gap-5">
          {fields.map(({ key, label, min, max, fallback }) => (
            <div key={key}>
              <div className="mb-3 flex justify-between gap-2 text-xs">
                <label id={`label-${key}`}>{label}</label>
                <output className="tabular-nums text-muted-foreground">
                  {value[key] ?? fallback}%
                </output>
              </div>
              <Slider
                aria-labelledby={`label-${key}`}
                min={min}
                max={max}
                step={1}
                value={[value[key] ?? fallback]}
                onValueChange={([n]) => {
                  if (n !== undefined) onChange({ ...value, [key]: n });
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
