import { useEffect, useState, type ReactNode } from "react";
import { ShieldCheck, ArrowRight, LogOut } from "lucide-react";
import logo from "@/assets/crazy-pods-logo.png.asset.json";
import { Button } from "@/components/ui/button";

const AGE_SESSION_KEY = "crazypods-age-confirmed";

export function AgeGate({ children }: { children: ReactNode }) {
  const [confirmed, setConfirmed] = useState(false);
  const [rejected, setRejected] = useState(false);
  useEffect(() => {
    try {
      setConfirmed(sessionStorage.getItem(AGE_SESSION_KEY) === "18+");
    } catch {
      // Keep confirmation available when browser storage is disabled.
    }
  }, []);
  const confirm = () => {
    try {
      sessionStorage.setItem(AGE_SESSION_KEY, "18+");
    } catch {
      // Confirmation still works for the current page.
    }
    setConfirmed(true);
  };
  if (confirmed) return children;
  return (
    <main className="grid min-h-dvh place-items-center bg-background px-5 py-12">
      <section className="w-full max-w-md text-center" aria-labelledby="age-title">
        <img
          src={logo.url}
          alt="Crazy Pods"
          width={112}
          height={112}
          className="mx-auto h-28 w-28 rounded-lg border border-border object-cover"
        />
        <div
          className="mx-auto mt-8 flex h-16 w-16 items-center justify-center rounded-full border border-border bg-card font-display text-xl font-bold"
          aria-hidden="true"
        >
          18+
        </div>
        <h1
          id="age-title"
          className="mt-6 font-display text-2xl font-bold leading-snug sm:text-3xl"
        >
          {rejected ? "Acesso restrito a maiores de 18 anos" : "Você tem 18 anos ou mais?"}
        </h1>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
          {rejected
            ? "Você não pode acessar esta loja. Por favor, feche esta página."
            : "Confirme sua idade para continuar. Este site é destinado exclusivamente a maiores de 18 anos."}
        </p>
        {!rejected && (
          <div className="mt-8 grid gap-3">
            <Button
              variant="commerce"
              onClick={confirm}
              className="h-auto min-h-12 whitespace-normal py-3"
            >
              <ShieldCheck />
              Sim, tenho 18 anos ou mais
              <ArrowRight />
            </Button>
            <Button
              variant="ghost"
              onClick={() => setRejected(true)}
              className="min-h-12 text-muted-foreground"
            >
              <LogOut />
              Não tenho 18 anos
            </Button>
          </div>
        )}
        <p className="mt-8 border-t border-border pt-5 text-xs leading-relaxed text-muted-foreground">
          A confirmação é uma declaração de idade, não uma verificação de identidade.
        </p>
      </section>
    </main>
  );
}
