import type { CSSProperties } from "react";

export type PhotoLayout = { imageScale?: number; imageX?: number; imageY?: number };
export const DEFAULT_PHOTO_LAYOUT = { imageScale: 100, imageX: 0, imageY: 0 };

export function photoStyle(layout: PhotoLayout): CSSProperties {
  return {
    "--photo-scale": (layout.imageScale ?? 100) / 100,
    "--photo-x": `${layout.imageX ?? 0}%`,
    "--photo-y": `${layout.imageY ?? 0}%`,
  } as CSSProperties;
}
