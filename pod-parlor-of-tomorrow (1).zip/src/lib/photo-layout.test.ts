import { describe, expect, it } from "vitest";
import { photoStyle } from "./photo-layout";

describe("Photo layout", () => {
  it("keeps existing photos at their original size and centered", () => {
    expect(photoStyle({})).toEqual({ "--photo-scale": 1, "--photo-x": "0%", "--photo-y": "0%" });
  });
  it("applies saved size and horizontal and vertical offsets", () => {
    expect(photoStyle({ imageScale: 125, imageX: -10, imageY: 15 })).toEqual({
      "--photo-scale": 1.25,
      "--photo-x": "-10%",
      "--photo-y": "15%",
    });
  });
});
