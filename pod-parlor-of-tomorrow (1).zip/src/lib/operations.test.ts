import { describe, expect, it } from "vitest";
import { financialSummary, type Sale, type CashEntry } from "./operations";
describe("Financial summary", () => {
  it("counts confirmed sales as income but never counts cancelled sales", () => {
    const sales = [
      { status: "completed", total: 150 },
      { status: "cancelled", total: 100 },
    ] as Sale[];
    expect(financialSummary(sales, []).income).toBe(150);
  });
  it("adds other income and subtracts expenses from the balance", () => {
    const entries = [
      { kind: "income", amount: 80 },
      { kind: "expense", amount: 30 },
    ] as CashEntry[];
    expect(financialSummary([], entries)).toEqual({
      salesTotal: 0,
      income: 80,
      expenses: 30,
      balance: 50,
    });
  });
});
