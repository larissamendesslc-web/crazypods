import { afterEach, describe, expect, it, vi } from "vitest";
import { uploadPodImage } from "./upload";

const mocks = vi.hoisted(() => ({ removeBackground: vi.fn(), upload: vi.fn(), signed: vi.fn() }));
vi.mock("@imgly/background-removal", () => ({ removeBackground: mocks.removeBackground }));
vi.mock("@/integrations/supabase/client", () => ({
  supabase: { storage: { from: () => ({ upload: mocks.upload, createSignedUrl: mocks.signed }) } },
}));

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("Product photo uploads", () => {
  it("always removes the background and uploads a transparent PNG instead of the original JPG", async () => {
    const file = new File(["original"], "pod.jpg", { type: "image/jpeg" });
    const transparent = new Blob(["transparent"], { type: "image/png" });
    mocks.removeBackground.mockResolvedValue(transparent);
    mocks.upload.mockResolvedValue({ error: null });
    mocks.signed.mockResolvedValue({
      data: { signedUrl: "https://example.test/pod.png" },
      error: null,
    });
    vi.stubGlobal(
      "createImageBitmap",
      vi.fn().mockResolvedValue({ width: 2, height: 2, close: vi.fn() }),
    );
    vi.stubGlobal("crypto", { randomUUID: () => "photo" });
    vi.spyOn(HTMLCanvasElement.prototype, "getContext").mockReturnValue({
      drawImage: vi.fn(),
      getImageData: () => ({ data: new Uint8ClampedArray(16) }),
    } as unknown as CanvasRenderingContext2D);

    await expect(uploadPodImage(file)).resolves.toBe("https://example.test/pod.png");
    expect(mocks.removeBackground).toHaveBeenCalledWith(file, { output: { format: "image/png" } });
    expect(mocks.upload).toHaveBeenCalledWith("photo.png", transparent, {
      contentType: "image/png",
    });
  });
});
