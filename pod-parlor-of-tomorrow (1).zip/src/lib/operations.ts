import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
export const payments = { pix: "Pix", cash: "Dinheiro", card: "Cartão", other: "Outro" };
export type Payment = keyof typeof payments;
export type Inventory = {
  id: string;
  product_id: string;
  flavor: string;
  quantity: number;
  low_stock: number;
};
export type Sale = {
  id: string;
  customer: string;
  payment: string;
  total: number;
  status: string;
  sold_at: string;
  notes: string;
};
export type SaleItem = {
  id: string;
  sale_id: string;
  product_name: string;
  flavor: string;
  quantity: number;
  unit_price: number;
};
export type CashEntry = {
  id: string;
  kind: string;
  amount: number;
  description: string;
  category: string;
  payment: string;
  occurred_on: string;
};
export function financialSummary(sales: Sale[], entries: CashEntry[]) {
  const salesTotal = sales
    .filter((s) => s.status === "completed")
    .reduce((n, s) => n + Number(s.total), 0);
  const extraIncome = entries
    .filter((e) => e.kind === "income")
    .reduce((n, e) => n + Number(e.amount), 0);
  const expenses = entries
    .filter((e) => e.kind === "expense")
    .reduce((n, e) => n + Number(e.amount), 0);
  return {
    salesTotal,
    income: salesTotal + extraIncome,
    expenses,
    balance: salesTotal + extraIncome - expenses,
  };
}
export const operationsQuery = queryOptions({
  queryKey: ["operations"],
  queryFn: async () => {
    const results = await Promise.all([
      supabase.from("inventory").select("*"),
      supabase.from("sales").select("*").order("sold_at", { ascending: false }),
      supabase.from("sale_items").select("*"),
      supabase.from("cash_entries").select("*").order("occurred_on", { ascending: false }),
    ]);
    for (const result of results) if (result.error) throw result.error;
    return {
      inventory: results[0].data as Inventory[],
      sales: results[1].data as Sale[],
      items: results[2].data as SaleItem[],
      entries: results[3].data as CashEntry[],
    };
  },
});
export function csvCell(value: unknown) {
  return `"${String(value ?? "")
    .replaceAll('"', '""')
    .replace(/^[=+@-]/, "'$&")}"`;
}
