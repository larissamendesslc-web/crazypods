import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { PhotoLayout } from "@/lib/photo-layout";

export const CATEGORIES = [
  { id: "ignite", label: "Ignite" },
  { id: "elfbar", label: "Elfbar" },
  { id: "lostmary", label: "Lost Mary" },
  { id: "oxbar", label: "Oxbar" },
  { id: "waka", label: "Waka" },
  { id: "outras", label: "Outras marcas" },
] as const;

export type Product = PhotoLayout & {
  id: string;
  slug: string;
  name: string;
  category: string;
  brand: string;
  price: number;
  puffs: number;
  note: string;
  flavors: string[];
  image: string | null;
  launch: boolean;
  soldout: boolean;
  rechargeable: boolean;
  sort: number;
};

export type ProductRow = {
  id: string;
  name: string;
  category: string;
  brand: string;
  price: number;
  puffs: number;
  description: string;
  flavors: string[];
  image_url: string | null;
  is_launch: boolean;
  sold_out: boolean;
  rechargeable: boolean;
  sort_order: number;
  image_scale?: number;
  image_x?: number;
  image_y?: number;
};

export const toProduct = (r: ProductRow): Product => ({
  id: r.id,
  slug: r.id,
  name: r.name,
  category: r.category,
  brand: r.brand,
  price: Number(r.price),
  puffs: r.puffs,
  note: r.description,
  flavors: r.flavors ?? [],
  image: r.image_url,
  launch: r.is_launch,
  soldout: r.sold_out,
  rechargeable: r.rechargeable,
  sort: r.sort_order,
  imageScale: r.image_scale ?? 100,
  imageX: r.image_x ?? 0,
  imageY: r.image_y ?? 0,
});

export const productsQuery = queryOptions({
  queryKey: ["products"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .order("sort_order")
      .order("created_at");
    if (error) throw error;
    return (data as ProductRow[]).map(toProduct);
  },
});
