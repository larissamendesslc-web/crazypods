import { createFileRoute, Link } from "@tanstack/react-router";
import { ShopShell } from "@/components/shop";
import { CatalogBrowser } from "@/components/catalog-browser";

export const Route = createFileRoute("/pods")({
  validateSearch: (s: Record<string, unknown>): { q?: string | undefined } => ({
    q: typeof s["q"] === "string" && s["q"] ? s["q"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Todos os pods — Crazy Pods" },
      {
        name: "description",
        content:
          "Catálogo completo de pods descartáveis Crazy Pods: todas as marcas, puffs e sabores.",
      },
      { property: "og:title", content: "Todos os pods — Crazy Pods" },
      { property: "og:description", content: "Catálogo completo com todas as marcas e sabores." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <ShopShell>
      <AllPods />
    </ShopShell>
  ),
});

function AllPods() {
  const { q } = Route.useSearch();
  return (
    <>
      <section className="chrome-band">
        <div className="mx-auto max-w-7xl px-5 py-10 md:py-14">
          <p className="text-sm text-muted-foreground">
            <Link to="/" className="hover:text-foreground">
              Início
            </Link>{" "}
            / Todos os pods
          </p>
          <h1 className="catalog-heading store-heading mt-4 font-display font-bold">
            Todos os pods
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Encontre sua marca e escolha seu sabor.
          </p>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-5">
        <CatalogBrowser initialQuery={q ?? ""} />
      </section>
    </>
  );
}
