import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ShieldCheck,
  Truck,
  CreditCard,
  Headphones,
  Zap,
  ArrowRight,
  ArrowUpRight,
  Pause,
  Play,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import heroBannerImg from "@/assets/dinner-lady-luma-40k-prata.jpg";
import { productsQuery, type Product } from "@/lib/products";
import {
  ShopShell,
  useShop,
  useReveal,
  brandCats,
  extraCats,
  match,
  ProductGrid,
  WhatsAppIcon,
  useSettings,
  PodImage,
  brl,
} from "@/components/shop";

import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Crazy Pods — Pods originais com entrega rápida" },
      {
        name: "description",
        content:
          "Os melhores pods descartáveis: Elfbar, Lost Mary, Ignite e mais. Escolha por marca ou puffs, entrega rápida em Osasco e SP.",
      },
      { property: "og:title", content: "Crazy Pods — Pods originais" },
      { property: "og:description", content: "Pods descartáveis originais com entrega rápida." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <ShopShell>
      <Home />
    </ShopShell>
  ),
});

const SPOT_NAMES = ["Ignite V155 Ultra", "Geek Bar 35.000", "Waka 50.000", "Elfbar 15.000"];

function Home() {
  const { data: catalog = [] } = useQuery(productsQuery);
  useReveal(catalog.length);
  const { openPod } = useShop();
  const { s: settings, WA } = useSettings();
  const [spot, setSpot] = useState(0);
  const [paused, setPaused] = useState(false);
  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setSpot((s) => s + 1), 6500);
    return () => clearInterval(t);
  }, [paused]);
  const spots = (
    settings.featuredIds.length
      ? settings.featuredIds.map((id) => catalog.find((p) => p.id === id))
      : SPOT_NAMES.map((n) => catalog.find((p) => p.name === n))
  ).filter((p): p is Product => !!p && !!p.image);
  const cur = spots[spot % Math.max(1, spots.length)];
  const launches = catalog
    .map((p, i) => ({ p, i }))
    .filter(({ p }) => p.launch && !p.soldout)
    .slice(0, 4);
  const openHero = () => {
    const i = settings.heroProductId
      ? catalog.findIndex((p) => p.id === settings.heroProductId)
      : catalog.findIndex((p) => /luma 40k/i.test(p.name));
    const p = catalog[i];
    if (p) openPod(p, i);
  };
  return (
    <>
      <section className="relative overflow-hidden">
        <h1 className="sr-only">Crazy Pods — escolha seu pod</h1>
        <Button
          variant="ghost"
          onClick={openHero}
          aria-label="Ver lançamento em destaque"
          className="block h-auto w-full rounded-none p-0 hover:bg-transparent"
        >
          <img
            src={settings.heroImage ?? heroBannerImg}
            alt="Lançamento em destaque na Crazy Pods"
            width={1672}
            height={941}
            fetchPriority="high"
            className="mx-auto block h-auto max-h-[680px] w-full object-contain"
          />
        </Button>
      </section>
      <section className="chrome-band">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-x-5 gap-y-4 px-5 py-5 md:grid-cols-4">
          {[
            [Truck, "Entrega rápida", "Osasco e região de SP"],
            [ShieldCheck, "Originais", "Procedência garantida"],
            [CreditCard, "Pagamento fácil", "Pix ou cartão"],
            [Headphones, "Atendimento", "Fale com a Crazy"],
          ].map(([I, t, d]) => {
            const Icon = I as typeof Zap;
            return (
              <div key={String(t)} className="flex items-center gap-3">
                <Icon className="h-6 w-6 shrink-0 text-foreground" />
                <div>
                  <p className="text-sm font-bold">{String(t)}</p>
                  <p className="text-xs text-muted-foreground">{String(d)}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="store-section chrome-band">
        <div className="mx-auto max-w-7xl px-5">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="mb-2 text-xs font-bold text-muted-foreground">SUAS MARCAS FAVORITAS</p>
              <h2 className="store-heading font-display font-bold">Escolha por marca</h2>
            </div>
            <Button variant="secondary" asChild>
              <Link to="/pods">
                Todos os pods <ArrowUpRight />
              </Link>
            </Button>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            {brandCats.map((c) => (
              <Button
                key={c.id}
                asChild
                variant="ghost"
                className="group h-auto whitespace-normal rounded-lg border border-border bg-background p-4 text-foreground hover:bg-secondary hover:text-foreground"
              >
                <Link to="/categoria/$cat" params={{ cat: c.id }} className="flex flex-col">
                  <div className="flex h-24 w-full items-center justify-center">
                    {c.logo ? (
                      <img
                        src={c.logo}
                        alt={c.label}
                        loading="lazy"
                        className="brand-logo-light max-h-20 w-full max-w-32 object-contain transition duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <span className="font-display text-xl font-bold">+ MARCAS</span>
                    )}
                  </div>
                  <div className="mt-4 flex w-full items-center justify-between border-t border-border pt-3">
                    <span className="text-xs text-muted-foreground">
                      {catalog.filter((p) => match(p, c.id)).length} modelos
                    </span>
                    <ArrowUpRight className="h-4 w-4" />
                  </div>
                </Link>
              </Button>
            ))}
          </div>
        </div>
      </section>

      <section className="store-section">
        <div className="mx-auto max-w-7xl px-5">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="mb-2 text-xs font-bold text-muted-foreground">DO SEU JEITO</p>
              <h2 className="store-heading font-display font-bold">Encontre seu próximo pod</h2>
            </div>
            <p className="text-sm text-muted-foreground">Novidades, puffs ou recarregáveis</p>
          </div>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {extraCats.map((c) => (
              <Button
                key={c.id}
                asChild
                variant="ghost"
                className="group h-auto items-start whitespace-normal rounded-lg border border-border p-5 text-left text-foreground transition hover:-translate-y-1 hover:bg-secondary hover:text-foreground"
              >
                <Link to="/categoria/$cat" params={{ cat: c.id }} className="flex flex-col gap-3">
                  <div className="flex w-full justify-between">
                    <c.icon className="h-6 w-6" />
                    <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-1" />
                  </div>
                  <span className="font-bold">{c.label}</span>
                  <span className="min-h-10 text-xs font-normal leading-relaxed text-muted-foreground group-hover:text-foreground">
                    {c.desc}
                  </span>
                  <span className="mt-2 text-xs">
                    {catalog.filter((p) => match(p, c.id)).length} modelos
                  </span>
                </Link>
              </Button>
            ))}
          </div>
        </div>
      </section>

      {cur && (
        <section
          className="border-y border-border bg-product-stage"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocusCapture={() => setPaused(true)}
          onBlurCapture={() => setPaused(false)}
        >
          <div className="mx-auto grid max-w-7xl items-center gap-8 px-5 py-12 md:grid-cols-2 md:py-16">
            <div>
              <p className="text-xs font-bold text-muted-foreground">NA VITRINE CRAZY</p>
              <h2 className="product-name mt-4 font-display text-3xl font-bold md:text-4xl">
                {cur.name}
              </h2>
              <p className="mt-4 text-muted-foreground">
                {cur.puffs.toLocaleString("pt-BR")} puffs · {cur.flavors.length} sabores
              </p>
              <p className="mt-6 font-display text-3xl font-bold">{brl(cur.price)}</p>
              <Button
                variant="commerce"
                className="mt-6 h-12 rounded-full"
                onClick={() => openPod(cur, catalog.indexOf(cur))}
              >
                Escolher sabor
                <ArrowRight />
              </Button>
              <div className="mt-7 flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={paused ? "Retomar destaques" : "Pausar destaques"}
                  onClick={() => setPaused((p) => !p)}
                >
                  {paused ? <Play /> : <Pause />}
                </Button>
                {spots.map((p, i) => (
                  <Button
                    key={p.id}
                    variant="ghost"
                    size="icon"
                    aria-label={`Mostrar ${p.name}`}
                    aria-pressed={i === spot % spots.length}
                    onClick={() => setSpot(i)}
                  >
                    <span
                      className={`h-2.5 w-2.5 rounded-full ${i === spot % spots.length ? "bg-primary" : "bg-muted-foreground/40"}`}
                    />
                  </Button>
                ))}
              </div>
            </div>
            <div className="flex h-64 items-center justify-center md:h-96">
              <PodImage
                p={cur}
                i={spot}
                className="h-full w-full max-w-sm animate-float object-contain"
              />
            </div>
          </div>
        </section>
      )}

      {launches.length > 0 && (
        <section className="store-section">
          <div className="mx-auto max-w-7xl px-5">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="mb-2 text-xs font-bold text-muted-foreground">NOVIDADES</p>
                <h2 className="store-heading font-display font-bold">Acabou de chegar</h2>
              </div>
              <Button variant="ghost" asChild>
                <Link to="/categoria/$cat" params={{ cat: "lancamentos" }}>
                  Ver lançamentos
                  <ArrowUpRight />
                </Link>
              </Button>
            </div>
            <ProductGrid list={launches} />
          </div>
        </section>
      )}

      <section className="chrome-band">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-5 py-10 md:flex-row md:items-center">
          <div>
            <p className="text-xs font-bold text-muted-foreground">CATÁLOGO COMPLETO</p>
            <h2 className="mt-2 font-display text-2xl font-bold">
              Todos os pods. Todos os sabores.
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              {catalog.length} modelos na Crazy Pods.
            </p>
          </div>
          <Button asChild variant="commerce" className="h-12">
            <Link to="/pods">
              Explorar catálogo
              <ArrowRight />
            </Link>
          </Button>
        </div>
      </section>
      <section className="store-section">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 pl-5 pr-24 md:flex-row md:items-center">
          <div>
            <h2 className="product-name font-display text-2xl font-bold">{settings.ctaTitle}</h2>
            <p className="mt-3 max-w-xl text-sm text-muted-foreground">{settings.ctaText}</p>
          </div>
          <Button asChild className="h-12 bg-whatsapp text-primary-foreground hover:bg-whatsapp/90">
            <a href={WA} target="_blank" rel="noopener noreferrer">
              <WhatsAppIcon />
              Falar com a Crazy Pods
            </a>
          </Button>
        </div>
      </section>
    </>
  );
}
