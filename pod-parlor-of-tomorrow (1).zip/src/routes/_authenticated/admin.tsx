import logo from "@/assets/crazy-pods-logo.png.asset.json";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, LogOut, Search, X, Upload, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { uploadPodImage } from "@/lib/upload";
import { AdminSettings } from "@/components/admin-settings";
import { AdminOperations, type OperationsView } from "@/components/admin-operations";
import { Button } from "@/components/ui/button";
import { PhotoLayoutEditor } from "@/components/photo-layout-editor";
import { DEFAULT_PHOTO_LAYOUT, photoStyle, type PhotoLayout } from "@/lib/photo-layout";
import { CATEGORIES, productsQuery, type Product } from "@/lib/products";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Painel — Crazy Pods" },
      { name: "description", content: "Gerencie os pods da Crazy Pods." },
      { property: "og:title", content: "Painel — Crazy Pods" },
      { property: "og:description", content: "Gerencie os pods da Crazy Pods." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const catLabel = (id: string) => CATEGORIES.find((c) => c.id === id)?.label ?? id;

type Form = PhotoLayout & {
  id?: string;
  name: string;
  category: string;
  brand: string;
  price: string;
  puffs: string;
  description: string;
  flavors: string;
  image_url: string | null;
  is_launch: boolean;
  sold_out: boolean;
  rechargeable: boolean;
};
const empty: Form = {
  ...DEFAULT_PHOTO_LAYOUT,
  name: "",
  category: "ignite",
  brand: "Ignite",
  price: "",
  puffs: "",
  description: "",
  flavors: "",
  image_url: null,
  is_launch: false,
  sold_out: false,
  rechargeable: false,
};

const schema = z.object({
  name: z.string().trim().min(1, "Informe o nome").max(120),
  category: z.enum(CATEGORIES.map((c) => c.id) as [string, ...string[]]),
  brand: z.string().trim().max(60),
  price: z.number({ message: "Preço inválido" }).min(0).max(100000),
  puffs: z.number().int().min(0).max(1000000),
  description: z.string().trim().max(1000),
  flavors: z.array(z.string().trim().min(1).max(80)).max(60),
});

function useIsAdmin() {
  return useQuery({
    queryKey: ["is-admin"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return false;
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", u.user.id)
        .eq("role", "admin")
        .maybeSingle();
      return !!data;
    },
  });
}

function AdminPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data: isAdmin, isLoading: roleLoading } = useIsAdmin();
  const { data: products = [], isLoading } = useQuery(productsQuery);
  const [cat, setCat] = useState("todos");
  const [q, setQ] = useState("");
  const [form, setForm] = useState<Form | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [tab, setTab] = useState<"pods" | "site" | OperationsView>("overview");

  const list = useMemo(
    () =>
      products.filter(
        (p) =>
          (cat === "todos" || p.category === cat) && p.name.toLowerCase().includes(q.toLowerCase()),
      ),
    [products, cat, q],
  );

  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  const edit = (p: Product) =>
    setForm({
      id: p.id,
      name: p.name,
      category: p.category,
      brand: p.brand,
      price: String(p.price),
      puffs: String(p.puffs),
      description: p.note,
      flavors: p.flavors.join("\n"),
      image_url: p.image,
      imageScale: p.imageScale ?? 100,
      imageX: p.imageX ?? 0,
      imageY: p.imageY ?? 0,
      is_launch: p.launch,
      sold_out: p.soldout,
      rechargeable: p.rechargeable,
    });

  const upload = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Envie uma imagem.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Imagem maior que 10MB.");
      return;
    }
    setUploading(true);
    try {
      const url = await uploadPodImage(file);
      setForm((f) => (f ? { ...f, image_url: url } : f));
      toast.success("Fundo removido e foto enviada!");
    } catch {
      toast.error("Falha ao enviar a imagem.");
    }
    setUploading(false);
  };

  const save = async () => {
    if (!form) return;
    const parsed = schema.safeParse({
      ...form,
      price: Number(form.price.replace(",", ".")),
      puffs: Number(form.puffs || 0),
      flavors: form.flavors
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean),
    });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message);
      return;
    }
    setSaving(true);
    const row = {
      ...parsed.data,
      image_url: form.image_url,
      image_scale: form.imageScale ?? 100,
      image_x: form.imageX ?? 0,
      image_y: form.imageY ?? 0,
      is_launch: form.is_launch,
      sold_out: form.sold_out,
      rechargeable: form.rechargeable,
    };
    const { error } = form.id
      ? await supabase.from("products").update(row).eq("id", form.id)
      : await supabase.from("products").insert({ ...row, sort_order: products.length });
    setSaving(false);
    if (error) {
      toast.error("Não foi possível salvar.");
      return;
    }
    toast.success(form.id ? "Pod atualizado!" : "Pod adicionado!");
    setForm(null);
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  const remove = async (p: Product) => {
    if (!confirm(`Excluir "${p.name}"?`)) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) {
      toast.error("Não foi possível excluir.");
      return;
    }
    toast.success("Pod excluído.");
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  const toggle = async (p: Product, field: "sold_out" | "is_launch", value: boolean) => {
    const { error } = await supabase
      .from("products")
      .update(field === "sold_out" ? { sold_out: value } : { is_launch: value })
      .eq("id", p.id);
    if (error) {
      toast.error("Não foi possível atualizar.");
      return;
    }
    qc.invalidateQueries({ queryKey: ["products"] });
  };

  if (roleLoading)
    return (
      <div className="grid min-h-screen place-items-center text-muted-foreground">
        Carregando...
      </div>
    );
  if (!isAdmin)
    return (
      <div className="grid min-h-screen place-items-center px-4 text-center">
        <div>
          <h1 className="font-display text-2xl font-bold">Sem permissão</h1>
          <p className="mt-2 text-muted-foreground">Esta conta não é administradora.</p>
          <button
            onClick={signOut}
            className="mt-6 rounded-full bg-secondary px-6 py-3 font-semibold"
          >
            Sair
          </button>
        </div>
      </div>
    );

  const input =
    "mt-1 w-full rounded-xl border border-input bg-secondary px-4 py-2.5 text-sm outline-none focus:border-primary";

  return (
    <div className="min-h-screen">
      <header className="glass sticky top-0 z-30 border-x-0 border-t-0">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-5 py-4">
          <Link to="/" className="block shrink-0">
            <img
              src={logo.url}
              alt="Crazy Pods"
              width={56}
              height={56}
              className="h-14 w-14 rounded-xl object-cover"
            />
          </Link>
          <span className="rounded-full bg-secondary px-3 py-1 text-xs font-bold">Painel</span>
          <Link
            to="/"
            className="ml-auto flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
          >
            <ExternalLink className="h-4 w-4" />
            Ver loja
          </Link>
          <button
            onClick={signOut}
            className="flex items-center gap-1 rounded-full bg-secondary px-4 py-2 text-sm font-semibold"
          >
            <LogOut className="h-4 w-4" />
            Sair
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-5 py-8">
        <div className="mb-8 flex flex-wrap gap-2">
          {(
            [
              ["overview", "Visão geral"],
              ["stock", "Estoque"],
              ["sales", "Vendas"],
              ["finance", "Financeiro"],
              ["pods", "Pods"],
              ["site", "Configurar site"],
            ] as const
          ).map(([id, l]) => (
            <Button
              key={id}
              onClick={() => setTab(id)}
              variant={tab === id ? "commerce" : "ghost"}
              className="h-auto whitespace-normal px-4 py-2.5 text-sm font-bold"
            >
              {l}
            </Button>
          ))}
        </div>
        {tab === "site" ? (
          <AdminSettings />
        ) : tab !== "pods" ? (
          <AdminOperations view={tab} />
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <h1 className="font-display text-3xl font-bold">
                Pods{" "}
                <span className="text-base font-medium text-muted-foreground">
                  · {products.length} cadastrados
                </span>
              </h1>
              <button
                onClick={() => setForm({ ...empty })}
                className="flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3 font-bold text-primary-foreground shadow-glow transition hover:scale-105"
              >
                <Plus className="h-5 w-5" />
                Novo pod
              </button>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-2">
              {[{ id: "todos", label: "Todos" }, ...CATEGORIES].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCat(c.id)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition ${cat === c.id ? "bg-gradient-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
                >
                  {c.label}{" "}
                  <span className="opacity-70">
                    (
                    {c.id === "todos"
                      ? products.length
                      : products.filter((p) => p.category === c.id).length}
                    )
                  </span>
                </button>
              ))}
              <div className="ml-auto flex items-center gap-2 rounded-full bg-secondary px-4 py-2">
                <Search className="h-4 w-4 text-muted-foreground" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Buscar..."
                  className="w-40 bg-transparent text-sm outline-none"
                />
              </div>
            </div>

            <div className="mt-6 overflow-hidden rounded-2xl border border-border">
              {isLoading ? (
                <p className="p-8 text-center text-muted-foreground">Carregando...</p>
              ) : (
                list.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center gap-4 border-b border-border bg-card/50 p-3 last:border-0 hover:bg-card"
                  >
                    <div className="bg-product-stage grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-md">
                      {p.image ? (
                        <img
                          src={p.image}
                          alt=""
                          className="pod-fly h-full w-full object-contain p-1"
                          style={photoStyle(p)}
                          loading="lazy"
                        />
                      ) : (
                        <span className="text-xs text-silver-foreground">sem foto</span>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold">{p.name}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {catLabel(p.category)} · {p.flavors.length} sabores
                        {p.puffs ? ` · ${p.puffs.toLocaleString("pt-BR")} puffs` : ""}
                      </p>
                    </div>
                    <p className="hidden font-display font-bold sm:block">{brl(p.price)}</p>
                    <label className="hidden items-center gap-1 text-xs md:flex">
                      <input
                        type="checkbox"
                        checked={p.launch}
                        onChange={(e) => toggle(p, "is_launch", e.target.checked)}
                        className="accent-primary"
                      />
                      Lançamento
                    </label>
                    <label className="hidden items-center gap-1 text-xs md:flex">
                      <input
                        type="checkbox"
                        checked={p.soldout}
                        onChange={(e) => toggle(p, "sold_out", e.target.checked)}
                        className="accent-destructive"
                      />
                      Esgotado
                    </label>
                    <button
                      aria-label="Editar"
                      onClick={() => edit(p)}
                      className="rounded-full bg-secondary p-2 hover:bg-primary"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      aria-label="Excluir"
                      onClick={() => remove(p)}
                      className="rounded-full bg-secondary p-2 hover:bg-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))
              )}
              {!isLoading && list.length === 0 && (
                <p className="p-8 text-center text-muted-foreground">Nenhum pod encontrado.</p>
              )}
            </div>
          </>
        )}
      </main>

      {form && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur-md"
          onClick={() => setForm(null)}
        >
          <div
            className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-border bg-card p-6 shadow-glow"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold">
                {form.id ? "Editar pod" : "Novo pod"}
              </h2>
              <button
                aria-label="Fechar"
                onClick={() => setForm(null)}
                className="rounded-full bg-secondary p-2"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-[160px_1fr]">
              <div>
                <label className="bg-product-stage group relative grid h-40 cursor-pointer place-items-center overflow-hidden rounded-lg border-2 border-dashed border-border hover:border-primary">
                  {form.image_url ? (
                    <img
                      src={form.image_url}
                      alt=""
                      className="pod-fly absolute inset-0 h-full w-full object-contain p-3"
                      style={photoStyle(form)}
                    />
                  ) : (
                    <span className="flex flex-col items-center gap-1 text-xs text-muted-foreground">
                      <Upload className="h-5 w-5" />
                      Enviar imagem
                    </span>
                  )}
                  {uploading && (
                    <span className="absolute inset-0 grid place-items-center bg-background/70 p-2 text-center text-xs">
                      Removendo fundo…
                    </span>
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    disabled={uploading}
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
                  />
                </label>
              </div>
              <div className="grid gap-3">
                <div>
                  <label className="text-sm font-semibold">Nome</label>
                  <input
                    className={input}
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Ex: Ignite V80"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-semibold">Categoria</label>
                    <select
                      className={input}
                      value={form.category}
                      onChange={(e) => {
                        const c = e.target.value;
                        setForm({
                          ...form,
                          category: c,
                          brand: c === "outras" ? form.brand : catLabel(c),
                        });
                      }}
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-semibold">Marca</label>
                    <input
                      className={input}
                      value={form.brand}
                      onChange={(e) => setForm({ ...form, brand: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            </div>
            {form.image_url && (
              <PhotoLayoutEditor
                image={form.image_url}
                value={form}
                onChange={(layout) =>
                  setForm((current) => (current ? { ...current, ...layout } : current))
                }
              />
            )}
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-semibold">Preço (R$)</label>
                <input
                  className={input}
                  inputMode="decimal"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  placeholder="85,00"
                />
              </div>
              <div>
                <label className="text-sm font-semibold">Puffs</label>
                <input
                  className={input}
                  inputMode="numeric"
                  value={form.puffs}
                  onChange={(e) => setForm({ ...form, puffs: e.target.value.replace(/\D/g, "") })}
                  placeholder="30000"
                />
              </div>
            </div>
            <div className="mt-3">
              <label className="text-sm font-semibold">Descrição</label>
              <textarea
                className={input}
                rows={2}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Ex: Pod com tela touch, função gelo..."
              />
            </div>
            <div className="mt-3">
              <label className="text-sm font-semibold">
                Sabores <span className="font-normal text-muted-foreground">(um por linha)</span>
              </label>
              <textarea
                className={input}
                rows={6}
                value={form.flavors}
                onChange={(e) => setForm({ ...form, flavors: e.target.value })}
                placeholder={"Menta\nMorango gelado\nUva"}
              />
            </div>
            <div className="mt-4 flex flex-wrap gap-4 text-sm">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  className="accent-primary"
                  checked={form.is_launch}
                  onChange={(e) => setForm({ ...form, is_launch: e.target.checked })}
                />
                Lançamento
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  className="accent-primary"
                  checked={form.sold_out}
                  onChange={(e) => setForm({ ...form, sold_out: e.target.checked })}
                />
                Esgotado
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  className="accent-primary"
                  checked={form.rechargeable}
                  onChange={(e) => setForm({ ...form, rechargeable: e.target.checked })}
                />
                Com bateria / cartucho
              </label>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setForm(null)}
                className="rounded-full bg-secondary px-6 py-3 font-semibold"
              >
                Cancelar
              </button>
              <button
                disabled={saving || uploading}
                onClick={save}
                className="rounded-full border border-input bg-commerce px-8 py-3 font-bold text-commerce-foreground disabled:opacity-60"
              >
                {saving ? "Salvando..." : "Salvar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
