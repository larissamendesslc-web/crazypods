import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CatalogBrowser } from "@/components/catalog-browser";
import { productsQuery } from "@/lib/products";
import { ShopShell, brandCats, extraCats, catLabel, match, type Cat } from "@/components/shop";

export const Route = createFileRoute("/categoria/$cat")({
  loader: ({ params }) => {
    const label = catLabel(params.cat);
    if (!label) throw notFound();
    return { label };
  },
  head: ({ loaderData }) => {
    const l = loaderData?.label ?? "Categoria";
    return {
      meta: [
        { title: `${l} — Crazy Pods` },
        {
          name: "description",
          content: `Pods ${l} originais na Crazy Pods: escolha o sabor e peça pelo WhatsApp.`,
        },
        { property: "og:title", content: `${l} — Crazy Pods` },
        { property: "og:description", content: `Veja os pods ${l} disponíveis na Crazy Pods.` },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <ShopShell>
      <div className="py-32 text-center">
        <p className="font-display text-2xl font-bold">Categoria não encontrada</p>
        <Link to="/pods" className="mt-4 inline-block text-primary-glow">
          Ver todos os pods
        </Link>
      </div>
    </ShopShell>
  ),
  component: () => (
    <ShopShell>
      <CategoryPage />
    </ShopShell>
  ),
});

function CategoryPage() {
  const { cat } = Route.useParams();
  const id = cat as Cat;
  const { data: catalog = [] } = useQuery(productsQuery);
  const brand = brandCats.find((c) => c.id === id);
  const extra = extraCats.find((c) => c.id === id);
  const count = catalog.filter((p) => match(p, id)).length;
  const Icon = extra?.icon;
  return (
    <>
      <section className="chrome-band">
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center sm:flex sm:justify-between gap-5 px-5 py-10 md:py-14">
          <div className="min-w-0">
            <p className="text-sm text-muted-foreground">
              <Link to="/">Início</Link> / <Link to="/pods">Todos os pods</Link> / {catLabel(id)}
            </p>
            <h1 className="catalog-heading store-heading mt-4 font-display font-bold">
              {catLabel(id)}
            </h1>
            <p className="mt-3 text-sm text-muted-foreground">
              {extra?.desc ?? `Explore os modelos ${brand?.label ?? "de outras marcas"}`} · {count}{" "}
              modelos
            </p>
          </div>
          {brand?.logo && (
            <img
              src={brand.logo}
              alt={brand.label}
              className="brand-logo-light h-16 w-24 object-contain md:h-24 md:w-44"
            />
          )}
          {Icon && <Icon className="h-14 w-14 shrink-0 text-muted-foreground" />}
        </div>
      </section>
      <nav aria-label="Marcas" className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-5 pt-6">
        {brandCats.map((c) => (
          <Link
            key={c.id}
            to="/categoria/$cat"
            params={{ cat: c.id }}
            aria-current={c.id === id ? "page" : undefined}
            className={`shrink-0 rounded-md px-4 py-2 text-sm font-semibold ${c.id === id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            {c.label}
          </Link>
        ))}
      </nav>
      <section className="mx-auto max-w-7xl px-5">
        <CatalogBrowser key={id} category={id} />
      </section>
    </>
  );
}
